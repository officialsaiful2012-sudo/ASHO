export type UserRole = 'member' | 'admin' | 'super_admin';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  phone: string;
  photoURL?: string;
  organizationId: string;
  role: UserRole;
  permissions: string[];
  status: 'active' | 'inactive';
  bloodGroup?: string;
  address?: string;
  isDonor?: boolean;
  isVolunteer?: boolean;
  createdAt: any;
  updatedAt: any;
}

export interface ServiceCategory {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  icon: string;
  color: string;
  active: boolean;
  order: number;
}

export type BloodGroup = 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';

export interface BloodDonor {
  id: string;
  userId?: string;
  name: string;
  phone: string;
  bloodGroup: BloodGroup;
  photoURL?: string;
  address: string;
  donationCount: number;
  lastDonationDate?: string;
  isAvailable: boolean;
  createdAt: any;
}

export interface BloodRequest {
  id: string;
  patientName: string;
  bloodGroup: BloodGroup;
  hospital: string;
  location: string;
  requiredDate: string;
  units: number;
  contact: string;
  urgency: 'normal' | 'emergency' | 'critical';
  status: 'pending' | 'fulfilled' | 'cancelled';
  notes?: string;
  requesterUid: string;
  requesterName: string;
  createdAt: any;
}

export interface HumanitarianActivity {
  id: string;
  title: string;
  description: string;
  category: string;
  imageUrl?: string;
  date: string;
  location: string;
  participants: number;
  beneficiaries: number;
  budget: number;
  status: 'ongoing' | 'completed';
  createdBy?: string;
  createdAt: any;
}

export interface OrgMember {
  id: string;
  userId?: string;
  name: string;
  photoURL?: string;
  phone: string;
  email?: string;
  bloodGroup?: string;
  position: string;
  joiningDate: string;
  address: string;
  status: 'active' | 'inactive';
  order?: number;
}

export interface OrgVolunteer {
  id: string;
  userId?: string;
  name: string;
  photoURL?: string;
  phone: string;
  skills: string[];
  availability: 'weekdays' | 'weekends' | 'anytime';
  bloodGroup?: string;
  joiningDate: string;
  status: 'active' | 'inactive';
}

export interface Contribution {
  id: string;
  memberId?: string;
  memberName: string;
  expectedAmount: number;
  paidAmount: number;
  dueAmount: number;
  month: string;
  paymentDate: string;
  paymentMethod: string;
  notes?: string;
  createdAt: any;
}

export interface Donation {
  id: string;
  donorName: string;
  phone?: string;
  amount: number;
  purpose: string;
  paymentMethod: string;
  transactionId?: string;
  date: string;
  isAnonymous?: boolean;
  status: 'approved' | 'pending';
  createdAt: any;
}

export interface Expense {
  id: string;
  title: string;
  category: string;
  amount: number;
  date: string;
  voucherNo?: string;
  description?: string;
  createdAt: any;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  category: 'notice' | 'announcement' | 'meeting' | 'event' | 'urgent';
  date: string;
  eventDate?: string;
  location?: string;
  priority: 'normal' | 'urgent';
  authorName?: string;
  createdAt: any;
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderPhoto?: string;
  recipientId?: string; // empty means public community welfare room
  text: string;
  imageUrl?: string;
  isSeen: boolean;
  createdAt: any;
}

export interface AppNotification {
  id: string;
  userId?: string; // empty means broadcast to all
  title: string;
  message: string;
  type: 'message' | 'blood' | 'notice' | 'event' | 'service' | 'finance';
  read: boolean;
  link?: string;
  createdAt: any;
}
