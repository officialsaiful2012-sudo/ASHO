import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Header } from './components/Header';
import { BottomNav, AppTab } from './components/BottomNav';
import { NotificationsModal } from './components/NotificationsModal';
import { AuthModal } from './components/AuthModal';
import { HomeScreen } from './screens/HomeScreen';
import { ServicesScreen } from './screens/ServicesScreen';
import { BloodScreen } from './screens/BloodScreen';
import { ActivitiesScreen } from './screens/ActivitiesScreen';
import { NoticesScreen } from './screens/NoticesScreen';
import { FinanceScreen } from './screens/FinanceScreen';
import { MembersScreen } from './screens/MembersScreen';
import { ChatScreen } from './screens/ChatScreen';
import { AdminScreen } from './screens/AdminScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { MessageCircle } from 'lucide-react';
import { generateAndroidProjectZip } from './utils/androidProjectZip';
import {
  subscribeServices,
  subscribeBloodRequests,
  subscribeBloodDonors,
  subscribeActivities,
  subscribeNotices,
  subscribeMembers,
  subscribeVolunteers,
  subscribeFinance,
  subscribeMessages,
  subscribeNotifications,
} from './services/firestoreService';
import {
  ServiceCategory,
  BloodRequest,
  BloodDonor,
  HumanitarianActivity,
  Notice,
  OrgMember,
  OrgVolunteer,
  Contribution,
  Donation,
  Expense,
  ChatMessage,
  AppNotification,
} from './types';

function MainAppContent() {
  const { currentUser, isAdmin, isSuperAdmin } = useAuth();
  const [activeTab, setActiveTab] = useState<AppTab>('home');

  // Modals
  const [showNotifications, setShowNotifications] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authHint, setAuthHint] = useState<string | undefined>(undefined);

  // Firestore Real-Time Data States
  const [services, setServices] = useState<ServiceCategory[]>([]);
  const [bloodRequests, setBloodRequests] = useState<BloodRequest[]>([]);
  const [bloodDonors, setBloodDonors] = useState<BloodDonor[]>([]);
  const [activities, setActivities] = useState<HumanitarianActivity[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [members, setMembers] = useState<OrgMember[]>([]);
  const [volunteers, setVolunteers] = useState<OrgVolunteer[]>([]);
  const [financeData, setFinanceData] = useState<{
    contributions: Contribution[];
    donations: Donation[];
    expenses: Expense[];
    summary: {
      totalContributions: number;
      totalDonations: number;
      totalExpenses: number;
      balance: number;
    };
  }>({
    contributions: [],
    donations: [],
    expenses: [],
    summary: {
      totalContributions: 0,
      totalDonations: 0,
      totalExpenses: 0,
      balance: 0,
    },
  });
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  // Real-time Firestore Listeners
  useEffect(() => {
    const unsubServices = subscribeServices(setServices);
    const unsubRequests = subscribeBloodRequests(setBloodRequests);
    const unsubDonors = subscribeBloodDonors(setBloodDonors);
    const unsubActivities = subscribeActivities(setActivities);
    const unsubNotices = subscribeNotices(setNotices);
    const unsubMembers = subscribeMembers(setMembers);
    const unsubVolunteers = subscribeVolunteers(setVolunteers);
    const unsubFinance = subscribeFinance(setFinanceData);
    const unsubMessages = subscribeMessages(setMessages);
    const unsubNotifications = subscribeNotifications(setNotifications);

    return () => {
      unsubServices();
      unsubRequests();
      unsubDonors();
      unsubActivities();
      unsubNotices();
      unsubMembers();
      unsubVolunteers();
      unsubFinance();
      unsubMessages();
      unsubNotifications();
    };
  }, []);

  const handleRequireAuth = (hint?: string) => {
    setAuthHint(hint);
    setShowAuthModal(true);
  };

  const handleDownloadAndroidZip = async () => {
    try {
      const a = document.createElement('a');
      a.href = '/release.apk';
      a.download = 'release.apk';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error('Download error:', err);
    }
  };

  const unreadNotifications = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 flex justify-center selection:bg-emerald-200">
      {/* Mobile-centric frame container (max-w-md looks and feels like a native phone) */}
      <div className="w-full max-w-md min-h-screen bg-white shadow-2xl flex flex-col relative border-x border-slate-200/60">
        {/* Top Header */}
        <Header
          notifications={notifications}
          onOpenNotifications={() => setShowNotifications(true)}
          onOpenChat={() => setActiveTab('chat')}
          onDownloadAndroidZip={handleDownloadAndroidZip}
          unreadCount={unreadNotifications}
        />

        {/* Screen Container */}
        <main className="flex-1 p-3.5 overflow-y-auto">
          {activeTab === 'home' && (
            <HomeScreen
              services={services}
              bloodRequests={bloodRequests}
              activities={activities}
              notices={notices}
              totalMembers={members.length}
              currentBalance={financeData.summary.balance}
              onNavigateTab={(tab) => setActiveTab(tab)}
              onRequestBlood={() => {
                setActiveTab('blood');
              }}
              onDonate={() => {
                setActiveTab('finance');
              }}
              onJoinVolunteer={() => {
                setActiveTab('members');
              }}
              onDownloadAndroidZip={handleDownloadAndroidZip}
            />
          )}

          {activeTab === 'services' && (
            <ServicesScreen
              services={services}
              onRequireAuth={handleRequireAuth}
              onRequestBlood={() => setActiveTab('blood')}
            />
          )}

          {activeTab === 'blood' && (
            <BloodScreen
              requests={bloodRequests}
              donors={bloodDonors}
              onRequireAuth={handleRequireAuth}
            />
          )}

          {activeTab === 'activities' && (
            <ActivitiesScreen
              activities={activities}
              onRequireAuth={handleRequireAuth}
            />
          )}

          {activeTab === 'notices' && (
            <NoticesScreen
              notices={notices}
              onRequireAuth={handleRequireAuth}
            />
          )}

          {activeTab === 'finance' && (
            <FinanceScreen
              contributions={financeData.contributions}
              donations={financeData.donations}
              expenses={financeData.expenses}
              summary={financeData.summary}
              onRequireAuth={handleRequireAuth}
            />
          )}

          {activeTab === 'members' && (
            <MembersScreen
              members={members}
              volunteers={volunteers}
              onRequireAuth={handleRequireAuth}
            />
          )}

          {activeTab === 'chat' && (
            <ChatScreen
              messages={messages}
              onRequireAuth={handleRequireAuth}
            />
          )}

          {activeTab === 'admin' && (
            <AdminScreen
              services={services}
              activities={activities}
              bloodRequests={bloodRequests}
              members={members}
              volunteers={volunteers}
              summary={financeData.summary}
              onNavigateTab={(tab) => setActiveTab(tab)}
            />
          )}

          {activeTab === 'profile' && (
            <ProfileScreen
              onDownloadAndroidZip={handleDownloadAndroidZip}
              onOpenAuth={() => handleRequireAuth()}
            />
          )}
        </main>

        {/* Floating Quick Live Chat Button in the bottom corner (as requested in requirement 26:
            "in the last corner attach a massage option this massage continue by internet all user canmassage in the apps") */}
        {activeTab !== 'chat' && (
          <button
            onClick={() => setActiveTab('chat')}
            className="fixed bottom-20 right-4 md:right-[calc(50%-13rem)] z-30 w-12 h-12 rounded-full bg-emerald-800 hover:bg-emerald-900 active:scale-95 text-white shadow-xl shadow-emerald-950/30 flex items-center justify-center transition border-2 border-amber-400 cursor-pointer"
            title="লাইভ চ্যাট / মেসেজ"
          >
            <MessageCircle size={22} />
            <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-400 rounded-full border-2 border-emerald-950 animate-pulse" />
          </button>
        )}

        {/* Material 3 Bottom Navigation Bar */}
        <BottomNav activeTab={activeTab} onChangeTab={setActiveTab} />

        {/* Modals */}
        <NotificationsModal
          isOpen={showNotifications}
          onClose={() => setShowNotifications(false)}
          notifications={notifications}
        />

        <AuthModal
          isOpen={showAuthModal}
          onClose={() => setShowAuthModal(false)}
          titleHint={authHint}
        />
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}
