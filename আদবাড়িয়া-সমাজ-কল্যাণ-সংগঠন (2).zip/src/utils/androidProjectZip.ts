import JSZip from 'jszip';

export async function generateAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // Root files
  zip.file('build.gradle.kts', `// Top-level build file
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
    id("com.google.gms.google-services") version "4.4.1" apply false
}
`);

  zip.file('settings.gradle.kts', `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "OurGoal"
include(":app")
`);

  zip.file('gradle.properties', `org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
android.nonTransitiveRClass=true
`);

  zip.file('gradle/wrapper/gradle-wrapper.properties', `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.5-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`);

  zip.file('key.properties.example', `# Release Keystore Configuration Example
# Copy this file to 'key.properties' and fill in your real keystore details
# Do NOT commit key.properties to git repository

storeFile=my-release-key.jks
storePassword=YOUR_KEYSTORE_PASSWORD
keyAlias=my-key-alias
keyPassword=YOUR_KEY_PASSWORD
`);

  zip.file('.gitignore', `*.iml
.gradle
/local.properties
/.idea/caches
/.idea/libraries
/.idea/modules.xml
/.idea/workspace.xml
.DS_Store
/build
/captures
.externalNativeBuild
.cxx
local.properties
*.jks
*.keystore
key.properties
`);

  zip.file('BUILD_INSTRUCTIONS.txt', `=====================================================
Our Goal — Release APK Build Instructions
আদবাড়িয়া সমাজ কল্যাণ সংগঠন
=====================================================

HOW TO BUILD PRODUCTION RELEASE APK (.apk):

Method 1: Using Android Studio (Recommended)
1. Open Android Studio.
2. Select "Open" and choose this project folder.
3. Wait for Gradle sync to complete.
4. In the top menu, go to:
   Build -> Build Bundle(s) / APK(s) -> Build APK(s)
5. Android Studio will generate the installable APK at:
   app/build/outputs/apk/release/app-release.apk

Method 2: Using Command Line (Terminal)
Run:
   ./gradlew assembleRelease

The generated Release APK will be located at:
   app/build/outputs/apk/release/app-release.apk

HOW TO INSTALL ON YOUR PHONE:
1. Copy 'app-release.apk' to your phone using USB cable, Google Drive, or WhatsApp.
2. On your phone, tap the file in File Manager or Downloads.
3. If prompted "Install unknown apps", tap Allow.
4. Tap "Install" to complete.
`);

  // App module
  const appFolder = zip.folder('app')!;
  
  // Real google-services.json
  appFolder.file('google-services.json', JSON.stringify({
    project_info: {
      project_number: "574145836431",
      firebase_url: "https://asho-c9c33-default-rtdb.firebaseio.com",
      project_id: "asho-c9c33",
      storage_bucket: "asho-c9c33.firebasestorage.app"
    },
    client: [
      {
        client_info: {
          mobilesdk_app_id: "1:574145836431:android:dc3e3348d19be83bf347fa",
          android_client_info: {
            package_name: "com.asho.asho"
          }
        },
        oauth_client: [
          {
            client_id: "574145836431-t7at1rq0lg08coh8op5gp6ho0kldqldr.apps.googleusercontent.com",
            client_type: 3
          }
        ],
        api_key: [
          {
            current_key: "AIzaSyCczrPb9-LcDkVz2aCavJX0DO9kUKzROhM"
          }
        ]
      }
    ],
    configuration_version: "1"
  }, null, 2));

  appFolder.file('build.gradle.kts', `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.asho.asho"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.asho.asho"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    signingConfigs {
        create("release") {
            val keystorePropertiesFile = rootProject.file("key.properties")
            if (keystorePropertiesFile.exists()) {
                val properties = java.util.Properties()
                properties.load(java.io.FileInputStream(keystorePropertiesFile))
                storeFile = file(properties.getProperty("storeFile") ?: "release.keystore")
                storePassword = properties.getProperty("storePassword")
                keyAlias = properties.getProperty("keyAlias")
                keyPassword = properties.getProperty("keyPassword")
            } else {
                // Secure testing fallback: uses debug keystore so APK can be directly installed on device
                val debugConfig = getByName("debug")
                storeFile = debugConfig.storeFile
                storePassword = debugConfig.storePassword
                keyAlias = debugConfig.keyAlias
                keyPassword = debugConfig.keyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.8"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")

    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")

    implementation(platform("com.google.firebase:firebase-bom:32.7.2"))
    implementation("com.google.firebase:firebase-auth-ktx")
    implementation("com.google.firebase:firebase-firestore-ktx")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.7.3")
    implementation("io.coil-kt:coil-compose:2.5.0")
}
`);

  // Manifest
  const mainFolder = appFolder.folder('src')?.folder('main')!;
  mainFolder.file('AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.CALL_PHONE" />

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.Adbariya">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
`);

  // Resources
  const resFolder = mainFolder.folder('res')!;
  const valuesFolder = resFolder.folder('values')!;
  valuesFolder.file('strings.xml', `<resources>
    <string name="app_name">Our Goal</string>
    <string name="org_name">আদবাড়িয়া সমাজ কল্যাণ সংগঠন</string>
    <string name="tagline">মানুষের পাশে, মানবতার জন্য</string>
</resources>
`);

  valuesFolder.file('themes.xml', `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.Adbariya" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:statusBarColor">#0D522C</item>
        <item name="android:navigationBarColor">#FFFFFF</item>
    </style>
</resources>
`);

  // Java/Kotlin code
  const pkgFolder = mainFolder.folder('java')?.folder('com')?.folder('asho')?.folder('asho')!;
  
  pkgFolder.file('MainActivity.kt', `package com.asho.asho

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.asho.asho.viewmodel.MainViewModel
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF0D522C),
                    secondary = Color(0xFFD4AF37),
                    background = Color(0xFFF8FAF9)
                )
            ) {
                MainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(mainViewModel: MainViewModel = viewModel()) {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Our Goal", style = MaterialTheme.typography.titleMedium)
                        Text("আদবাড়িয়া সমাজ কল্যাণ সংগঠন", style = MaterialTheme.typography.bodySmall, color = Color(0xFFD4AF37))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D522C),
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("হোম") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "Blood") },
                    label = { Text("রক্তদান") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.VolunteerActivism, contentDescription = "Activities") },
                    label = { Text("কার্যক্রম") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Forum, contentDescription = "Chat") },
                    label = { Text("মেসেজ") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            Text("Our Goal — আদবাড়িয়া সমাজ কল্যাণ সংগঠন মোবাইল অ্যাপ সফলভাবে প্রস্তুত।", modifier = Modifier.padding(16.dp))
        }
    }
}
`);

  pkgFolder.file('model/Models.kt', `package com.asho.asho.model

import com.google.firebase.Timestamp

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val photoURL: String = "",
    val organizationId: String = "adbariya-samaj-kalyan",
    val role: String = "member",
    val permissions: List<String> = emptyList(),
    val status: String = "active"
)

data class ServiceCategory(
    val id: String = "",
    val title: String = "",
    val titleEn: String = "",
    val description: String = "",
    val icon: String = "",
    val color: String = "#0D522C",
    val active: Boolean = true,
    val order: Int = 0
)

data class BloodDonor(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phone: String = "",
    val bloodGroup: String = "",
    val photoURL: String = "",
    val address: String = "",
    val isAvailable: Boolean = true
)

data class BloodRequest(
    val id: String = "",
    val patientName: String = "",
    val bloodGroup: String = "",
    val hospital: String = "",
    val location: String = "",
    val requiredDate: String = "",
    val units: Int = 1,
    val contact: String = "",
    val urgency: String = "emergency",
    val status: String = "pending"
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val imageUrl: String = "",
    val createdAt: Timestamp? = null
)
`);

  pkgFolder.file('repository/FirebaseRepository.kt', `package com.asho.asho.repository

import com.asho.asho.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    val superAdminUid = "SI5nqpVS0oYKv9ZFDWV6zNVnK5v1"

    val currentUserId: String? get() = auth.currentUser?.uid
    val isSuperAdmin: Boolean get() = currentUserId == superAdminUid

    fun getBloodRequestsFlow(): Flow<List<BloodRequest>> = callbackFlow {
        val listener = firestore.collection("bloodRequests")
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(BloodRequest::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    fun getMessagesFlow(): Flow<List<ChatMessage>> = callbackFlow {
        val listener = firestore.collection("messages")
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(ChatMessage::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(message: ChatMessage) {
        firestore.collection("messages").add(message).await()
    }
}
`);

  return await zip.generateAsync({ type: 'blob' });
}
