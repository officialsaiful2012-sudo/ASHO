/**
 * Image compression and external storage utility
 * Does NOT use Firebase Storage.
 */

export async function compressImage(file: File, maxWidth = 1024, maxHeight = 1024, quality = 0.75): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            maxHeight = height;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        // Compressed data URI
        const compressedDataUri = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedDataUri);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
}

/**
 * Upload to external free image host if configured or return compressed URL
 */
export async function uploadImageToExternalHost(
  compressedDataUri: string,
  externalApiKey?: string
): Promise<string> {
  // If an ImgBB or custom upload API key is provided by admin
  if (externalApiKey) {
    try {
      const base64Data = compressedDataUri.replace(/^data:image\/[a-z]+;base64,/, '');
      const formData = new FormData();
      formData.append('image', base64Data);

      const response = await fetch(`https://api.imgbb.com/1/upload?key=${externalApiKey}`, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      if (data && data.data && data.data.url) {
        return data.data.url;
      }
    } catch (err) {
      console.warn('External upload failed, using optimized local URI:', err);
    }
  }

  // Return the compressed URI safely
  return compressedDataUri;
}
