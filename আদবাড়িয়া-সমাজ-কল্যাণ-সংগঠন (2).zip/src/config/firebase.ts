import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

// Configuration from google-services.json
export const firebaseConfig = {
  apiKey: "AIzaSyCczrPb9-LcDkVz2aCavJX0DO9kUKzROhM",
  authDomain: "asho-c9c33.firebaseapp.com",
  databaseURL: "https://asho-c9c33-default-rtdb.firebaseio.com",
  projectId: "asho-c9c33",
  storageBucket: "asho-c9c33.firebasestorage.app",
  messagingSenderId: "574145836431",
  appId: "1:574145836431:android:dc3e3348d19be83bf347fa"
};

// Initialize Firebase
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const db = getFirestore(app);
export const SUPER_ADMIN_UID = "SI5nqpVS0oYKv9ZFDWV6zNVnK5v1";
export const DEFAULT_ORG_ID = "adbariya-samaj-kalyan";

export default app;
