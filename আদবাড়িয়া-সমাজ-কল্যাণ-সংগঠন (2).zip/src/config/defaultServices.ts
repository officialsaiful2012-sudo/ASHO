import { ServiceCategory } from '../types';

export const DEFAULT_SERVICE_CATEGORIES: Omit<ServiceCategory, 'id'>[] = [
  {
    title: 'রক্তদান সেবা',
    titleEn: 'Blood Donation',
    description: 'জরুরি রক্তের প্রয়োজনে রক্তের গ্রুপ অনুযায়ী নিয়মিত রক্তদাতা ও সেবা প্রাপ্তির নির্ভরযোগ্য ব্যবস্থা।',
    icon: 'HeartHandshake',
    color: '#DC2626', // Red
    active: true,
    order: 1,
  },
  {
    title: 'চিকিৎসা সহায়তা',
    titleEn: 'Medical Assistance',
    description: 'অসহায় রোগীদের বিনামূল্যে ও স্বল্পমূল্যে ওষুধ, চিকিৎসা ব্যয় ও জরুরি অ্যাম্বুলেন্স সহায়তা।',
    icon: 'Stethoscope',
    color: '#0284C7', // Blue
    active: true,
    order: 2,
  },
  {
    title: 'খাদ্য বিতরণ',
    titleEn: 'Food Distribution',
    description: 'দরিদ্র ও সুবিধা বঞ্চিত পরিবারগুলোর মাঝে পুষ্টিকর খাবার ও নিত্যপ্রয়োজনীয় খাদ্য সামগ্রী সরবরাহ।',
    icon: 'Utensils',
    color: '#D97706', // Amber
    active: true,
    order: 3,
  },
  {
    title: 'শিক্ষা সহায়তা',
    titleEn: 'Education Assistance',
    description: 'মেধাবী ও অসচ্ছল ছাত্রছাত্রীদের উপবৃত্তি, বই-খাতা, স্কুল ড্রেস ও পরীক্ষার ফি প্রদান।',
    icon: 'GraduationCap',
    color: '#7C3AED', // Purple
    active: true,
    order: 4,
  },
  {
    title: 'শীতবস্ত্র বিতরণ',
    titleEn: 'Winter Clothing Distribution',
    description: 'তীব্র শীতে অসহায় প্রবীণ, শিশু ও সুবিধাবঞ্চিত মানুষের মাঝে উষ্ণ কম্বল ও শীতের পোশাক বিতরণ।',
    icon: 'Wind',
    color: '#0D9488', // Teal
    active: true,
    order: 5,
  },
  {
    title: 'ত্রাণ বিতরণ',
    titleEn: 'Relief Distribution',
    description: 'বন্যা, ঝড় বা যেকোনো দুর্যোগ মুহূর্তে খাদ্যসামগ্রী, বিশুদ্ধ পানি ও ত্রাণ পৌঁছানো।',
    icon: 'PackageCheck',
    color: '#EA580C', // Orange
    active: true,
    order: 6,
  },
  {
    title: 'জরুরি সহায়তা',
    titleEn: 'Emergency Assistance',
    description: 'দুর্ঘটনা, আকস্মিক সংকট ও প্রাকৃতিক দুর্যোগে ২৪/৭ জরুরি মানবিক সাড়াদান টিম।',
    icon: 'AlertCircle',
    color: '#E11D48', // Rose
    active: true,
    order: 7,
  },
  {
    title: 'দরিদ্র পরিবারকে পুনর্বাসন',
    titleEn: 'Help for Poor Families',
    description: 'কর্মসংস্থান সৃষ্টি, স্বাবলম্বীকরণ সহায়তা ও বিধবা ও এতিম পরিবারকে স্থায়ী সহায়তা প্রদান।',
    icon: 'Home',
    color: '#059669', // Emerald
    active: true,
    order: 8,
  },
  {
    title: 'গৃহনির্মাণ ও সেবামূলক কাজ',
    titleEn: 'Construction & Service Assistance',
    description: 'গৃহহীনদের আশ্রয়ন মেরামত, নলকূপ স্থাপন ও স্যানিটেশন সেবামূলক অবকাঠামো নির্মাণ।',
    icon: 'Hammer',
    color: '#4F46E5', // Indigo
    active: true,
    order: 9,
  },
  {
    title: 'পরিবেশ ও বৃক্ষরোপণ কর্মসূচি',
    titleEn: 'Environmental Activities',
    description: 'সবুজ বাংলাদেশ গড়তে প্রতি মৌসুমে ফলদ, বনজ ও ঔষধি গাছ রোপণ ও পরিবেশ সংরক্ষণ ক্যাম্পেইন।',
    icon: 'Trees',
    color: '#16A34A', // Green
    active: true,
    order: 10,
  },
  {
    title: 'স্বেচ্ছাসেবক কার্যক্রম',
    titleEn: 'Volunteer Activities',
    description: 'নিবেদিতপ্রাণ যুবসমাজকে মানবসেবায় উদ্বুদ্ধকরণ ও সক্রিয় স্বেচ্ছাসেবা পরিচালনা।',
    icon: 'Users',
    color: '#2563EB', // Blue
    active: true,
    order: 11,
  },
  {
    title: 'অন্যান্য মানবিক সেবা',
    titleEn: 'Other Humanitarian Services',
    description: 'সামাজিক সচেতনতা, বাল্যবিয়ে রোধ, যৌতুক বিরোধী সামাজিক কার্যক্রম ও জনকল্যাণ সেবা।',
    icon: 'Smile',
    color: '#9333EA', // Purple
    active: true,
    order: 12,
  },
];
