import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile as updateFirebaseProfile,
} from 'firebase/auth';
import { auth, SUPER_ADMIN_UID } from '../config/firebase';
import { syncUserProfile, getUserProfile } from '../services/firestoreService';
import { UserProfile } from '../types';

interface AuthContextType {
  currentUser: User | null;
  profile: UserProfile | null;
  loading: boolean;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string, phone: string, photoURL?: string) => Promise<void>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const isSuperAdmin = currentUser?.uid === SUPER_ADMIN_UID || profile?.role === 'super_admin';
  const isAdmin = isSuperAdmin || profile?.role === 'admin';

  const refreshProfile = async () => {
    if (currentUser) {
      const p = await getUserProfile(currentUser.uid);
      if (p) setProfile(p);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        try {
          const userProfile = await syncUserProfile({
            uid: user.uid,
            email: user.email,
            displayName: user.displayName,
            phoneNumber: user.phoneNumber,
            photoURL: user.photoURL,
          });
          setProfile(userProfile);
        } catch (err) {
          console.error('Error syncing user profile:', err);
        }
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, []);

  const login = async (email: string, pass: string) => {
    const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
    const p = await syncUserProfile({
      uid: cred.user.uid,
      email: cred.user.email,
      displayName: cred.user.displayName,
      phoneNumber: cred.user.phoneNumber,
      photoURL: cred.user.photoURL,
    });
    setProfile(p);
  };

  const register = async (name: string, email: string, pass: string, phone: string, photoURL?: string) => {
    const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
    await updateFirebaseProfile(cred.user, {
      displayName: name,
      photoURL: photoURL || undefined,
    });

    const p = await syncUserProfile({
      uid: cred.user.uid,
      email: cred.user.email,
      displayName: name,
      phoneNumber: phone,
      photoURL: photoURL,
    });
    setProfile(p);
  };

  const logout = async () => {
    await signOut(auth);
    setCurrentUser(null);
    setProfile(null);
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        profile,
        loading,
        isAdmin,
        isSuperAdmin,
        login,
        register,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
