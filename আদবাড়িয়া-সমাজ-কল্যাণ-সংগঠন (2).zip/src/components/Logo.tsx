import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  showText?: boolean;
}

export const Logo: React.FC<LogoProps> = ({ className = '', size = 56, showText = false }) => {
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 300 300"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="shrink-0 drop-shadow-md select-none"
      >
        <defs>
          <radialGradient id="greenBg" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1B5E20" />
            <stop offset="70%" stopColor="#0E3D15" />
            <stop offset="100%" stopColor="#08280D" />
          </radialGradient>
          <radialGradient id="centerGlow" cx="50%" cy="55%" r="45%">
            <stop offset="0%" stopColor="#FFF9E6" />
            <stop offset="70%" stopColor="#F5EFE0" />
            <stop offset="100%" stopColor="#E2D6BE" />
          </radialGradient>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F7DF8D" />
            <stop offset="50%" stopColor="#D4AF37" />
            <stop offset="100%" stopColor="#997A15" />
          </linearGradient>
          <linearGradient id="sunGradient" x1="0%" y1="100%" x2="0%" y2="0%">
            <stop offset="0%" stopColor="#FF7A00" />
            <stop offset="100%" stopColor="#FFD200" />
          </linearGradient>
          <path id="topTextArc" d="M 45 150 A 105 105 0 0 1 255 150" fill="none" />
          <path id="bottomTextArc" d="M 250 150 A 100 100 0 0 1 50 150" fill="none" />
        </defs>

        {/* Outer Ring */}
        <circle cx="150" cy="150" r="146" fill="#0A0F0D" />
        <circle cx="150" cy="150" r="143" stroke="url(#goldGradient)" strokeWidth="4" />
        
        {/* Ornamental Border Ring */}
        <circle cx="150" cy="150" r="136" fill="url(#greenBg)" stroke="url(#goldGradient)" strokeWidth="3" />
        
        {/* Decorative Leaf dots around outer border */}
        {Array.from({ length: 24 }).map((_, i) => {
          const angle = (i * 360) / 24;
          const rad = (angle * Math.PI) / 180;
          const x = 150 + 137 * Math.cos(rad);
          const y = 150 + 137 * Math.sin(rad);
          return <circle key={i} cx={x} cy={y} r="1.5" fill="#F7DF8D" opacity="0.6" />;
        })}

        {/* Text Along Arcs */}
        <text fill="#FFFFFF" fontSize="19" fontWeight="700" letterSpacing="2" fontFamily="'Hind Siliguri', sans-serif">
          <textPath href="#topTextArc" startOffset="50%" textAnchor="middle">
            আদবাড়িয়া সমাজ কল্যাণ সংগঠন
          </textPath>
        </text>

        <text fill="#F7DF8D" fontSize="16" fontWeight="700" letterSpacing="4" fontFamily="'Hind Siliguri', sans-serif">
          <textPath href="#bottomTextArc" startOffset="50%" textAnchor="middle">
            ঐক্য • সেবা • উন্নয়ন
          </textPath>
        </text>

        {/* Inner Ring with Gold Border */}
        <circle cx="150" cy="150" r="92" fill="url(#centerGlow)" stroke="url(#goldGradient)" strokeWidth="3.5" />
        <circle cx="150" cy="150" r="88" stroke="#0E3D15" strokeWidth="1" strokeDasharray="3 3" opacity="0.4" />

        {/* Rising Sun */}
        <circle cx="175" cy="155" r="18" fill="url(#sunGradient)" />
        {/* Sun Rays */}
        {[-30, -15, 0, 15, 30, 45].map((angle, idx) => {
          const rad = ((angle - 90) * Math.PI) / 180;
          const x1 = 175 + 20 * Math.cos(rad);
          const y1 = 155 + 20 * Math.sin(rad);
          const x2 = 175 + 28 * Math.cos(rad);
          const y2 = 155 + 28 * Math.sin(rad);
          return <line key={idx} x1={x1} y1={y1} x2={x2} y2={y2} stroke="#FFA000" strokeWidth="2" strokeLinecap="round" />;
        })}

        {/* Distant Hills / Village houses */}
        {/* Left houses */}
        <rect x="110" y="160" width="14" height="12" fill="#78909C" rx="1" />
        <polygon points="107,160 117,152 127,160" fill="#BF360C" />
        <rect x="127" y="163" width="10" height="9" fill="#90A4AE" rx="1" />
        <polygon points="125,163 132,156 139,163" fill="#D84315" />

        {/* Right houses */}
        <rect x="180" y="163" width="12" height="9" fill="#90A4AE" rx="1" />
        <polygon points="178,163 186,156 194,163" fill="#BF360C" />

        {/* Mighty Banyan Tree */}
        <g id="banyanTree">
          {/* Canopy foliage */}
          <path
            d="M 150 78 
               C 135 78 122 88 122 102 
               C 110 102 100 112 100 124 
               C 100 134 107 142 116 145 
               C 114 150 118 156 125 156
               C 132 156 138 152 140 148
               C 145 152 155 152 160 148
               C 163 153 172 155 178 152
               C 185 156 195 152 198 144
               C 204 138 206 128 202 120
               C 205 110 198 98 188 95
               C 188 84 176 78 165 78
               Z"
            fill="#2E7D32"
          />
          {/* Detailed inner foliage highlights */}
          <circle cx="140" cy="100" r="14" fill="#388E3C" opacity="0.8" />
          <circle cx="160" cy="98" r="15" fill="#43A047" opacity="0.8" />
          <circle cx="130" cy="118" r="16" fill="#2E7D32" />
          <circle cx="150" cy="112" r="18" fill="#388E3C" />
          <circle cx="170" cy="116" r="16" fill="#43A047" opacity="0.9" />
          <circle cx="185" cy="125" r="12" fill="#2E7D32" />
          <circle cx="118" cy="132" r="12" fill="#1B5E20" />

          {/* Tree Trunk & Roots */}
          <path
            d="M 144 140 
               Q 142 155 140 170 
               Q 146 166 150 166 
               Q 154 166 160 170 
               Q 158 155 156 140 
               Z"
            fill="#4E342E"
          />
          {/* Aerial hanging roots */}
          <path d="M 132 135 Q 130 152 128 165" stroke="#5D4037" strokeWidth="2" strokeLinecap="round" />
          <path d="M 140 138 Q 138 155 137 167" stroke="#4E342E" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M 160 138 Q 162 155 163 167" stroke="#4E342E" strokeWidth="1.8" strokeLinecap="round" />
          <path d="M 168 135 Q 170 152 172 165" stroke="#5D4037" strokeWidth="2" strokeLinecap="round" />
        </g>

        {/* River stream flowing forward */}
        <path
          d="M 148 168 
             Q 150 180 144 195 
             Q 150 205 146 220 
             L 154 220 
             Q 156 205 154 195 
             Q 152 180 152 168 
             Z"
          fill="#4FC3F7"
          opacity="0.85"
        />

        {/* Cupped Supportive Human Hands */}
        {/* Left Hand */}
        <path
          d="M 98 150 
             C 98 175 110 205 140 216 
             C 134 212 126 200 120 188 
             C 114 176 108 162 108 152 
             C 105 150 100 148 98 150 
             Z"
          fill="#FFFFFF"
          stroke="#0E3D15"
          strokeWidth="1.5"
        />
        <path
          d="M 108 152 
             C 110 168 120 190 138 206 
             M 115 156 
             C 118 172 128 190 142 200"
          stroke="#0E3D15"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
        />

        {/* Right Hand */}
        <path
          d="M 202 150 
             C 202 175 190 205 160 216 
             C 166 212 174 200 180 188 
             C 186 176 192 162 192 152 
             C 195 150 200 148 202 150 
             Z"
          fill="#FFFFFF"
          stroke="#0E3D15"
          strokeWidth="1.5"
        />
        <path
          d="M 192 152 
             C 190 168 180 190 162 206 
             M 185 156 
             C 182 172 172 190 158 200"
          stroke="#0E3D15"
          strokeWidth="1.2"
          strokeLinecap="round"
          fill="none"
        />

        {/* Established 2026 Badge at Bottom of Inner Circle */}
        <g id="established">
          <rect x="110" y="210" width="80" height="17" rx="8.5" fill="#0E3D15" stroke="url(#goldGradient)" strokeWidth="1" />
          <text
            x="150"
            y="222"
            textAnchor="middle"
            fill="#FFF"
            fontSize="10"
            fontWeight="700"
            fontFamily="'Hind Siliguri', sans-serif"
          >
            প্রতিষ্ঠিত ২০২৬
          </text>
        </g>
      </svg>

      {showText && (
        <div className="flex flex-col">
          <span className="font-bold text-lg leading-tight text-emerald-950 font-['Hind_Siliguri']">
            আদবাড়িয়া সমাজ কল্যাণ সংগঠন
          </span>
          <span className="text-xs text-emerald-700 font-medium font-['Hind_Siliguri']">
            মানুষের পাশে, মানবতার জন্য
          </span>
        </div>
      )}
    </div>
  );
};
