import React from 'react';
import { X, Bell, Droplet, Megaphone, Heart, Sparkles, Check } from 'lucide-react';
import { AppNotification } from '../types';
import { markNotificationAsRead } from '../services/firestoreService';

interface NotificationsModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: AppNotification[];
}

export const NotificationsModal: React.FC<NotificationsModalProps> = ({
  isOpen,
  onClose,
  notifications,
}) => {
  if (!isOpen) return null;

  const handleMarkRead = async (id: string) => {
    try {
      await markNotificationAsRead(id);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl border border-emerald-100 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="bg-emerald-900 p-4 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell size={18} className="text-amber-400" />
            <h3 className="font-bold font-['Hind_Siliguri'] text-base">নোটিফিকেশনসমূহ</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 transition text-white"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto flex-1 divide-y divide-slate-100">
          {notifications.length === 0 ? (
            <div className="py-12 text-center text-slate-500 font-['Hind_Siliguri']">
              <Bell size={36} className="mx-auto mb-2 text-slate-300" />
              <p className="text-sm font-medium">কোনো নতুন নোটিফিকেশন নেই</p>
              <p className="text-xs text-slate-400 mt-1">সব নতুন ঘোষণা ও তথ্য এখানে প্রদর্শিত হবে</p>
            </div>
          ) : (
            notifications.map((n) => (
              <div
                key={n.id}
                className={`py-3 px-2 flex items-start gap-3 transition rounded-xl ${
                  !n.read ? 'bg-emerald-50/70 font-semibold' : 'hover:bg-slate-50'
                }`}
              >
                <div className="p-2 rounded-xl bg-white shadow-sm shrink-0 border border-slate-100">
                  {n.type === 'blood' ? (
                    <Droplet size={18} className="text-red-500" />
                  ) : n.type === 'notice' ? (
                    <Megaphone size={18} className="text-amber-500" />
                  ) : (
                    <Heart size={18} className="text-emerald-600" />
                  )}
                </div>
                <div className="flex-1 text-left">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-900 font-['Hind_Siliguri']">{n.title}</h4>
                    {!n.read && (
                      <button
                        onClick={() => handleMarkRead(n.id)}
                        className="text-[10px] text-emerald-700 hover:text-emerald-900 flex items-center gap-0.5"
                        title="পড়া হয়েছে চিহ্নিত করুন"
                      >
                        <Check size={12} /> পড়া হয়েছে
                      </button>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 mt-0.5 font-['Hind_Siliguri'] leading-relaxed">
                    {n.message}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
