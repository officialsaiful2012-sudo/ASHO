import React, { useState } from 'react';
import { Upload, Link as LinkIcon, Image as ImageIcon, X } from 'lucide-react';
import { compressImage } from '../utils/imageUpload';

interface ImageUploadInputProps {
  label: string;
  value?: string;
  onChange: (url: string) => void;
  required?: boolean;
}

export const ImageUploadInput: React.FC<ImageUploadInputProps> = ({
  label,
  value,
  onChange,
  required = false,
}) => {
  const [mode, setMode] = useState<'upload' | 'url'>('upload');
  const [compressing, setCompressing] = useState(false);
  const [urlInput, setUrlInput] = useState(value || '');

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setCompressing(true);
      // Compresses image to high-efficiency WebP/JPEG data URL or uploaded CDN URL without Firebase Storage
      const compressedUri = await compressImage(file, 800, 800, 0.7);
      onChange(compressedUri);
    } catch (err) {
      console.error('Image compression failed:', err);
    } finally {
      setCompressing(false);
    }
  };

  const handleUrlSubmit = () => {
    if (urlInput.trim()) {
      onChange(urlInput.trim());
    }
  };

  return (
    <div className="space-y-1.5 text-left">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-emerald-950 font-['Hind_Siliguri']">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
        <div className="flex items-center gap-1 text-[11px] text-emerald-800">
          <button
            type="button"
            onClick={() => setMode('upload')}
            className={`px-2 py-0.5 rounded transition ${
              mode === 'upload' ? 'bg-emerald-100 text-emerald-900 font-bold' : 'hover:bg-slate-100'
            }`}
          >
            ফাইল আপলোড
          </button>
          <span>|</span>
          <button
            type="button"
            onClick={() => setMode('url')}
            className={`px-2 py-0.5 rounded transition ${
              mode === 'url' ? 'bg-emerald-100 text-emerald-900 font-bold' : 'hover:bg-slate-100'
            }`}
          >
            অনলাইন লিংক (URL)
          </button>
        </div>
      </div>

      {value ? (
        <div className="relative group rounded-xl overflow-hidden border border-emerald-200 bg-slate-50 w-full h-36 flex items-center justify-center">
          <img src={value} alt="Preview" className="w-full h-full object-cover" />
          <button
            type="button"
            onClick={() => {
              onChange('');
              setUrlInput('');
            }}
            className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition shadow"
            title="মুছে ফেলুন"
          >
            <X size={14} />
          </button>
          <div className="absolute bottom-1 left-2 text-[10px] text-white/90 bg-black/40 px-1.5 py-0.5 rounded">
            ছবি প্রস্তুত আছে
          </div>
        </div>
      ) : mode === 'upload' ? (
        <label className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/50 hover:bg-emerald-50/80 rounded-xl p-4 flex flex-col items-center justify-center cursor-pointer transition">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="hidden"
            disabled={compressing}
          />
          {compressing ? (
            <div className="flex items-center gap-2 text-xs text-emerald-800 font-medium">
              <span className="w-4 h-4 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
              ছবি অপ্টিমাইজ হচ্ছে...
            </div>
          ) : (
            <>
              <Upload className="w-6 h-6 text-emerald-700 mb-1" />
              <span className="text-xs font-semibold text-emerald-900 font-['Hind_Siliguri']">
                ডিভাইস থেকে ছবি নির্বাচন করুন
              </span>
              <span className="text-[10px] text-emerald-600">
                স্বয়ংক্রিয়ভাবে অপ্টিমাইজ করা হবে (নো ফায়ারবেস স্টোরেজ)
              </span>
            </>
          )}
        </label>
      ) : (
        <div className="flex gap-2">
          <input
            type="url"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
            placeholder="https://example.com/image.jpg"
            className="flex-1 text-xs px-3 py-2 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
          <button
            type="button"
            onClick={handleUrlSubmit}
            className="px-3 py-2 bg-emerald-800 text-white text-xs font-medium rounded-xl hover:bg-emerald-900 transition flex items-center gap-1"
          >
            <LinkIcon size={12} /> সেট করুন
          </button>
        </div>
      )}
    </div>
  );
};
