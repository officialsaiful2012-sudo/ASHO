import React from 'react';
import {
  Home,
  HeartHandshake,
  Droplet,
  Flame,
  BellRing,
  Wallet,
  Users,
  MessageCircle,
  Shield,
  User,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export type AppTab =
  | 'home'
  | 'services'
  | 'blood'
  | 'activities'
  | 'notices'
  | 'finance'
  | 'members'
  | 'chat'
  | 'admin'
  | 'profile';

interface BottomNavProps {
  activeTab: AppTab;
  onChangeTab: (tab: AppTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  const { isAdmin, isSuperAdmin, currentUser } = useAuth();

  const navItems = [
    { id: 'home' as AppTab, label: 'হোম', icon: Home },
    { id: 'services' as AppTab, label: 'সেবা', icon: HeartHandshake },
    { id: 'blood' as AppTab, label: 'রক্তদান', icon: Droplet },
    { id: 'activities' as AppTab, label: 'কার্যক্রম', icon: Flame },
    { id: 'notices' as AppTab, label: 'নোটিশ', icon: BellRing },
    { id: 'finance' as AppTab, label: 'তহবিল', icon: Wallet },
    { id: 'members' as AppTab, label: 'সদস্য', icon: Users },
    { id: 'chat' as AppTab, label: 'মেসেজ', icon: MessageCircle },
    ...(isAdmin || isSuperAdmin ? [{ id: 'admin' as AppTab, label: 'অ্যাডমিন', icon: Shield }] : []),
    { id: 'profile' as AppTab, label: currentUser ? 'প্রোফাইল' : 'লগইন', icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200/80 shadow-[0_-4px_20px_rgba(0,0,0,0.06)]">
      <div className="max-w-screen-md mx-auto flex items-center justify-between px-1 py-1.5 overflow-x-auto no-scrollbar">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChangeTab(item.id)}
              className="flex-1 min-w-[52px] py-1 flex flex-col items-center justify-center transition-all duration-200 group relative"
            >
              {/* Material 3 active pill highlight */}
              <div
                className={`flex items-center justify-center w-12 h-7 rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-emerald-900 text-white shadow-md shadow-emerald-950/20 scale-105'
                    : 'text-slate-500 group-hover:text-emerald-900 group-hover:bg-emerald-50/60'
                }`}
              >
                <Icon size={18} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span
                className={`text-[10px] mt-0.5 tracking-tight font-['Hind_Siliguri'] font-medium transition-colors ${
                  isActive ? 'text-emerald-950 font-bold' : 'text-slate-600'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
