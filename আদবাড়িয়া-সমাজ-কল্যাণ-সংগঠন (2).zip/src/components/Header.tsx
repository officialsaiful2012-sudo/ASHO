import React from 'react';
import { Bell, MessageSquare, Download, ShieldCheck, UserCheck } from 'lucide-react';
import { Logo } from './Logo';
import { useAuth } from '../context/AuthContext';
import { AppNotification } from '../types';

interface HeaderProps {
  notifications: AppNotification[];
  onOpenNotifications: () => void;
  onOpenChat: () => void;
  onDownloadAndroidZip: () => void;
  unreadCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  notifications,
  onOpenNotifications,
  onOpenChat,
  onDownloadAndroidZip,
  unreadCount,
}) => {
  const { currentUser, profile, isAdmin, isSuperAdmin } = useAuth();

  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 text-white shadow-lg border-b border-emerald-800/40">
      {/* Android Top Status bar subtle simulation */}
      <div className="flex justify-between items-center px-4 pt-1.5 pb-0.5 text-[10px] text-emerald-200/80 font-mono select-none">
        <div className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>অনলাইন নেটওয়ার্ক</span>
        </div>
        <div className="flex items-center gap-2">
          <span>4G / LTE</span>
          <span>100%</span>
        </div>
      </div>

      {/* Main Material 3 Top App Bar */}
      <div className="px-3 py-2 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <Logo size={46} />
          <div className="flex flex-col text-left">
            <div className="flex items-center gap-1.5">
              <h1 className="font-bold text-sm md:text-base leading-tight font-['Hind_Siliguri'] tracking-tight">
                আদবাড়িয়া সমাজ কল্যাণ সংগঠন
              </h1>
              {isSuperAdmin && (
                <span className="bg-amber-400/90 text-slate-950 text-[10px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5 shadow-sm">
                  <ShieldCheck size={11} /> সুপার অ্যাডমিন
                </span>
              )}
              {!isSuperAdmin && isAdmin && (
                <span className="bg-emerald-400 text-slate-950 text-[10px] font-bold px-1.5 py-0.2 rounded-full flex items-center gap-0.5">
                  <ShieldCheck size={11} /> অ্যাডমিন
                </span>
              )}
            </div>
            <p className="text-[11px] text-emerald-200/90 font-medium font-['Hind_Siliguri']">
              মানুষের পাশে, মানবতার জন্য
            </p>
          </div>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1">
          {/* Android Studio Export Shortcut */}
          <button
            onClick={onDownloadAndroidZip}
            className="p-2 rounded-xl bg-emerald-800/60 hover:bg-emerald-700/80 active:scale-95 transition text-emerald-100 flex items-center gap-1 text-xs border border-emerald-700/50"
            title="অ্যান্ড্রয়েড স্টুডিও সোর্স কোড ডাউনলোড করুন"
          >
            <Download size={16} />
            <span className="hidden sm:inline text-[11px] font-['Hind_Siliguri']">APK কোড</span>
          </button>

          {/* Chat Shortcut */}
          <button
            onClick={onOpenChat}
            className="relative p-2 rounded-xl bg-emerald-800/60 hover:bg-emerald-700/80 active:scale-95 transition text-emerald-100 border border-emerald-700/50"
            title="লাইভ ইন্টারনেট মেসেজিং"
          >
            <MessageSquare size={17} />
          </button>

          {/* Notifications */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl bg-emerald-800/60 hover:bg-emerald-700/80 active:scale-95 transition text-emerald-100 border border-emerald-700/50"
            title="নোটিফিকেশনসমূহ"
          >
            <Bell size={17} />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce shadow">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
