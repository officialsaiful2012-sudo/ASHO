import React, { useState } from 'react';
import {
  Users,
  UserCheck,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Droplet,
  Plus,
  Shield,
  Trash2,
  Search,
} from 'lucide-react';
import { OrgMember, OrgVolunteer } from '../types';
import { useAuth } from '../context/AuthContext';
import { addMember, addVolunteer, deleteMember } from '../services/firestoreService';
import { ImageUploadInput } from '../components/ImageUploadInput';

interface MembersScreenProps {
  members: OrgMember[];
  volunteers: OrgVolunteer[];
  onRequireAuth: (hint: string) => void;
}

export const MembersScreen: React.FC<MembersScreenProps> = ({
  members,
  volunteers,
  onRequireAuth,
}) => {
  const { isAdmin, isSuperAdmin, currentUser } = useAuth();
  const [activeTab, setActiveTab] = useState<'members' | 'volunteers'>('members');
  const [searchTerm, setSearchTerm] = useState('');
  const [showMemberModal, setShowMemberModal] = useState(false);
  const [showVolunteerModal, setShowVolunteerModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // New Member form
  const [mName, setMName] = useState('');
  const [mPosition, setMPosition] = useState('কার্যনির্বাহী সদস্য');
  const [mPhone, setMPhone] = useState('');
  const [mEmail, setMEmail] = useState('');
  const [mBlood, setMBlood] = useState('O+');
  const [mAddress, setMAddress] = useState('আদবাড়িয়া');
  const [mPhoto, setMPhoto] = useState('');
  const [mOrder, setMOrder] = useState(10);

  // New Volunteer form
  const [vName, setVName] = useState('');
  const [vPhone, setVPhone] = useState('');
  const [vSkills, setVSkills] = useState('রক্তদান ব্যবস্থাপনা, ত্রাণ বিতরণ');
  const [vAvailability, setVAvailability] = useState<'weekdays' | 'weekends' | 'anytime'>('anytime');
  const [vBlood, setVBlood] = useState('A+');
  const [vPhoto, setVPhoto] = useState('');

  const filteredMembers = members.filter(
    (m) =>
      m.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.position.toLowerCase().includes(searchTerm.toLowerCase()) ||
      m.phone.includes(searchTerm)
  );

  const filteredVolunteers = volunteers.filter(
    (v) =>
      v.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.phone.includes(searchTerm)
  );

  const handleAddMember = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin && !isSuperAdmin) return;
    setSubmitting(true);
    try {
      await addMember({
        name: mName,
        position: mPosition,
        phone: mPhone,
        email: mEmail,
        bloodGroup: mBlood,
        address: mAddress,
        photoURL: mPhoto,
        joiningDate: new Date().toISOString().split('T')[0],
        status: 'active',
        order: Number(mOrder) || 99,
      });
      setShowMemberModal(false);
      setMName('');
      setMPhone('');
      setMPhoto('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleAddVolunteer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onRequireAuth('স্বেচ্ছাসেবক হিসেবে নিবন্ধন করতে লগইন প্রয়োজন');
      return;
    }
    setSubmitting(true);
    try {
      await addVolunteer({
        userId: currentUser.uid,
        name: vName,
        phone: vPhone,
        skills: vSkills.split(',').map((s) => s.trim()),
        availability: vAvailability,
        bloodGroup: vBlood,
        photoURL: vPhoto,
        joiningDate: new Date().toISOString().split('T')[0],
        status: 'active',
      });
      setShowVolunteerModal(false);
      setVName('');
      setVPhone('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteMember = async (id: string) => {
    if (confirm('আপনি কি এই সদস্যকে তালিকা থেকে মুছে ফেলতে চান?')) {
      await deleteMember(id);
    }
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-emerald-950 text-white rounded-3xl p-5 shadow-lg flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-amber-400 text-slate-950">
              <Users size={18} />
            </span>
            <h2 className="text-lg font-bold">কার্যনির্বাহী পরিষদ ও স্বেচ্ছাসেবী</h2>
          </div>
          <p className="text-xs text-emerald-200">
            সংগঠনের সম্মানিত পরিচালনা পর্ষদ ও মানবিক কাজে যুক্ত একঝাঁক তরুণ স্বেচ্ছাসেবী।
          </p>
        </div>

        <div className="flex gap-2">
          {activeTab === 'members' && (isAdmin || isSuperAdmin) && (
            <button
              onClick={() => setShowMemberModal(true)}
              className="px-3 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-xl transition shadow flex items-center gap-1 shrink-0 cursor-pointer"
            >
              <Plus size={15} /> সদস্য যোগ
            </button>
          )}
          {activeTab === 'volunteers' && (
            <button
              onClick={() => {
                if (!currentUser) onRequireAuth('স্বেচ্ছাসেবক হিসেবে নিবন্ধন করতে লগইন করুন');
                else setShowVolunteerModal(true);
              }}
              className="px-3 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-xl transition shadow flex items-center gap-1 shrink-0 cursor-pointer"
            >
              <Plus size={15} /> যুক্ত হোন
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-2xl bg-slate-200/80 p-1">
        <button
          onClick={() => setActiveTab('members')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'members'
              ? 'bg-white text-emerald-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          কমিটি সদস্য ({members.length})
        </button>
        <button
          onClick={() => setActiveTab('volunteers')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'volunteers'
              ? 'bg-white text-emerald-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          স্বেচ্ছাসেবক টিম ({volunteers.length})
        </button>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="নাম, পদবি বা মোবাইল নম্বর দিয়ে খুঁজুন..."
          className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-white"
        />
      </div>

      {/* Members Tab */}
      {activeTab === 'members' && (
        <div className="space-y-3">
          {filteredMembers.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <Users size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">কোনো পরিষদ সদস্য পাওয়া যায়নি</h4>
              <p className="text-xs text-slate-400 mt-1">
                অ্যাডমিন প্যানেল থেকে কার্যনির্বাহী সদস্যদের পদবি ও তথ্য যুক্ত করা যাবে।
              </p>
            </div>
          ) : (
            filteredMembers.map((member) => (
              <div
                key={member.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center justify-between gap-3 hover:border-emerald-200 transition"
              >
                <div className="flex items-center gap-3">
                  {member.photoURL ? (
                    <img
                      src={member.photoURL}
                      alt={member.name}
                      className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-base shrink-0">
                      {member.name.charAt(0)}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-slate-900">{member.name}</h4>
                      {member.bloodGroup && (
                        <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.2 rounded font-bold">
                          {member.bloodGroup}
                        </span>
                      )}
                    </div>

                    <div className="text-xs font-semibold text-emerald-800 mt-0.5">
                      {member.position}
                    </div>

                    <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-1">
                      <span>{member.address}</span>
                      <span>•</span>
                      <span>যোগদান: {member.joiningDate}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${member.phone}`}
                    className="p-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-xl transition"
                    title="কল দিন"
                  >
                    <Phone size={15} />
                  </a>
                  {(isAdmin || isSuperAdmin) && (
                    <button
                      onClick={() => handleDeleteMember(member.id)}
                      className="p-2 text-slate-400 hover:text-red-600 rounded-xl transition"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 size={15} />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Volunteers Tab */}
      {activeTab === 'volunteers' && (
        <div className="space-y-3">
          {filteredVolunteers.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <UserCheck size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">কোনো স্বেচ্ছাসেবী তালিকাভুক্ত নেই</h4>
              <p className="text-xs text-slate-400 mt-1">
                সংগঠনের মানবিক কার্যক্রমে অংশগ্রহণ করতে যেকেউ স্বেচ্ছাসেবী হিসেবে যুক্ত হতে পারেন।
              </p>
            </div>
          ) : (
            filteredVolunteers.map((vol) => (
              <div
                key={vol.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  {vol.photoURL ? (
                    <img
                      src={vol.photoURL}
                      alt={vol.name}
                      className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-base shrink-0">
                      {vol.name.charAt(0)}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-slate-900">{vol.name}</h4>
                      {vol.bloodGroup && (
                        <span className="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.2 rounded font-bold">
                          {vol.bloodGroup}
                        </span>
                      )}
                    </div>

                    <div className="text-[11px] text-slate-600 mt-0.5">
                      দক্ষতা: {vol.skills?.join(', ') || 'সাধারণ সেবামূলক কাজ'}
                    </div>

                    <div className="text-[10px] text-emerald-700 font-semibold mt-0.5">
                      উপলব্ধতা: {vol.availability === 'anytime' ? 'সবসময়' : vol.availability === 'weekends' ? 'ছুটির দিনে' : 'কর্মদিবসে'}
                    </div>
                  </div>
                </div>

                <a
                  href={`tel:${vol.phone}`}
                  className="p-2 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 rounded-xl transition"
                >
                  <Phone size={15} />
                </a>
              </div>
            ))
          )}
        </div>
      )}

      {/* Add Member Modal */}
      {showMemberModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">কমিটি সদস্য যুক্ত করুন</h3>
              <button onClick={() => setShowMemberModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleAddMember} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সদস্যের নাম *</label>
                <input
                  type="text"
                  required
                  value={mName}
                  onChange={(e) => setMName(e.target.value)}
                  placeholder="পূর্ণ নাম"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সাংগঠনিক পদবি *</label>
                <input
                  type="text"
                  required
                  value={mPosition}
                  onChange={(e) => setMPosition(e.target.value)}
                  placeholder="সভাপতি / সাধারণ সম্পাদক / সদস্য"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">মোবাইল নম্বর *</label>
                  <input
                    type="tel"
                    required
                    value={mPhone}
                    onChange={(e) => setMPhone(e.target.value)}
                    placeholder="০১৭১২-XXXXXX"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">রক্তের গ্রুপ</label>
                  <select
                    value={mBlood}
                    onChange={(e) => setMBlood(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl bg-white"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ঠিকানা</label>
                  <input
                    type="text"
                    value={mAddress}
                    onChange={(e) => setMAddress(e.target.value)}
                    placeholder="আদবাড়িয়া"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ক্রম নম্বর (Order)</label>
                  <input
                    type="number"
                    value={mOrder}
                    onChange={(e) => setMOrder(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <ImageUploadInput
                label="সদস্যের ছবি"
                value={mPhoto}
                onChange={setMPhoto}
              />

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-emerald-800 text-white font-bold text-xs rounded-xl"
              >
                সংরক্ষণ করুন
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Add Volunteer Modal */}
      {showVolunteerModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">স্বেচ্ছাসেবক হিসেবে নিবন্ধন</h3>
              <button onClick={() => setShowVolunteerModal(false)} className="text-slate-400 font-bold">✕</button>
            </div>

            <form onSubmit={handleAddVolunteer} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">আপনার নাম *</label>
                <input
                  type="text"
                  required
                  value={vName}
                  onChange={(e) => setVName(e.target.value)}
                  placeholder="পূর্ণ নাম"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">মোবাইল নম্বর *</label>
                  <input
                    type="tel"
                    required
                    value={vPhone}
                    onChange={(e) => setVPhone(e.target.value)}
                    placeholder="০১৭১২-XXXXXX"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">রক্তের গ্রুপ</label>
                  <select
                    value={vBlood}
                    onChange={(e) => setVBlood(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl bg-white"
                  >
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">দক্ষতা / অভিজ্ঞতার ক্ষেত্র</label>
                <input
                  type="text"
                  value={vSkills}
                  onChange={(e) => setVSkills(e.target.value)}
                  placeholder="যেমন: রক্তদান ব্যবস্থাপনা, কম্পিউটার, ত্রাণ বণ্টন"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সময় দেওয়ার সুবিধা</label>
                <select
                  value={vAvailability}
                  onChange={(e) => setVAvailability(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl bg-white"
                >
                  <option value="anytime">যেকোনো জরুরি প্রয়োজনে (২৪/৭)</option>
                  <option value="weekends">শুধুমাত্র ছুটির দিনে</option>
                  <option value="weekdays">কর্মদিবসে</option>
                </select>
              </div>

              <ImageUploadInput
                label="আপনার ছবি (ঐচ্ছিক)"
                value={vPhoto}
                onChange={setVPhoto}
              />

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-emerald-800 text-white font-bold text-xs rounded-xl"
              >
                স্বেচ্ছাসেবক হিসেবে জমা দিন
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
