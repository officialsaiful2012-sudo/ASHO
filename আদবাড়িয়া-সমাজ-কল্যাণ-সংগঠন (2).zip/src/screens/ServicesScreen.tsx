import React, { useState } from 'react';
import {
  Heart,
  Search,
  ArrowRight,
  ShieldAlert,
  Send,
  CheckCircle,
  HelpCircle,
  Phone,
  Sparkles,
  Info,
} from 'lucide-react';
import { ServiceCategory } from '../types';
import { useAuth } from '../context/AuthContext';

interface ServicesScreenProps {
  services: ServiceCategory[];
  onRequireAuth: (hint: string) => void;
  onRequestBlood: () => void;
}

export const ServicesScreen: React.FC<ServicesScreenProps> = ({
  services,
  onRequireAuth,
  onRequestBlood,
}) => {
  const { currentUser } = useAuth();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedService, setSelectedService] = useState<ServiceCategory | null>(null);
  const [requestSubmitted, setRequestSubmitted] = useState(false);
  const [requestDetails, setRequestDetails] = useState({
    name: '',
    phone: '',
    address: '',
    notes: '',
  });

  const filteredServices = services.filter((s) =>
    s.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    s.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (s.titleEn && s.titleEn.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleApplyClick = (service: ServiceCategory) => {
    if (!currentUser) {
      onRequireAuth(`"${service.title}" সেবার জন্য আবেদন করতে লগইন প্রয়োজন`);
      return;
    }
    if (service.title.includes('রক্তদান')) {
      onRequestBlood();
      return;
    }
    setSelectedService(service);
    setRequestSubmitted(false);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRequestSubmitted(true);
    setTimeout(() => {
      setSelectedService(null);
      setRequestSubmitted(false);
      setRequestDetails({ name: '', phone: '', address: '', notes: '' });
    }, 2500);
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-900 to-emerald-950 text-white rounded-3xl p-5 shadow-md">
        <h2 className="text-lg font-bold">মানবকল্যাণ ও সামাজিক সেবাসমূহ</h2>
        <p className="text-xs text-emerald-200 mt-1">
          আদবাড়িয়া সমাজ কল্যাণ সংগঠনের ১২টি মৌলিক মানবিক সেবা বিভাগ। যেকোনো নাগরিক এই সেবাগুলোতে আবেদন করতে পারেন।
        </p>

        {/* Search */}
        <div className="mt-3 relative">
          <Search className="absolute left-3 top-2.5 text-slate-400" size={16} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="সেবা খুঁজুন (যেমন: খাদ্য, চিকিৎসা, রক্ত...)"
            className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl bg-white/95 text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-400"
          />
        </div>
      </div>

      {/* Services List */}
      {filteredServices.length === 0 ? (
        <div className="py-16 text-center bg-white rounded-3xl border border-slate-200 p-6">
          <Heart size={40} className="mx-auto text-slate-300 mb-2" />
          <h4 className="font-bold text-sm text-slate-700">কোনো সেবা পাওয়া যায়নি</h4>
          <p className="text-xs text-slate-400 mt-1">
            ফায়ারবেস ডাটাবেজে এখনো কোনো সেবা ক্যাটাগরি তৈরি হয়নি। অ্যাডমিন প্যানেলে গিয়ে ডিফল্ট সেবাসমূহ ইমপোর্ট বা নতুন সেবা যোগ করতে পারেন।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredServices.map((service, index) => (
            <div
              key={service.id || index}
              className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-emerald-300 hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div
                    className="w-10 h-10 rounded-2xl flex items-center justify-center text-white shadow-xs shrink-0"
                    style={{ backgroundColor: service.color || '#0D522C' }}
                  >
                    <Heart size={20} />
                  </div>
                  {service.titleEn && (
                    <span className="text-[10px] font-medium text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">
                      {service.titleEn}
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-sm text-slate-900 mb-1">{service.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{service.description}</p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-[11px] text-emerald-800 font-medium flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  সক্রিয় সেবা
                </span>
                <button
                  onClick={() => handleApplyClick(service)}
                  className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 active:scale-95 text-white text-xs font-semibold rounded-xl transition flex items-center gap-1 shadow-xs cursor-pointer"
                >
                  সেবা গ্রহণ করুন <ArrowRight size={12} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Service Application Modal */}
      {selectedService && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100">
            {requestSubmitted ? (
              <div className="py-8 text-center space-y-2">
                <CheckCircle size={48} className="text-emerald-600 mx-auto" />
                <h3 className="font-bold text-base text-slate-900">আবেদন সফলভাবে গ্রহণ করা হয়েছে!</h3>
                <p className="text-xs text-slate-600">
                  আদবাড়িয়া সমাজ কল্যাণ সংগঠনের দায়িত্বশীল টিম খুব শীঘ্রই আপনার প্রদত্ত মোবাইল নম্বরে যোগাযোগ করবেন।
                </p>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded">
                      সেবার আবেদন
                    </span>
                    <h3 className="font-bold text-base text-slate-900 mt-1">{selectedService.title}</h3>
                  </div>
                  <button
                    onClick={() => setSelectedService(null)}
                    className="text-slate-400 hover:text-slate-600 text-sm font-bold"
                  >
                    ✕
                  </button>
                </div>

                <form onSubmit={handleFormSubmit} className="space-y-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      সুবিধাভোগীর নাম <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={requestDetails.name}
                      onChange={(e) => setRequestDetails({ ...requestDetails, name: e.target.value })}
                      placeholder="আবেদনকারী বা রোগীর নাম"
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      মোবাইল নম্বর <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={requestDetails.phone}
                      onChange={(e) => setRequestDetails({ ...requestDetails, phone: e.target.value })}
                      placeholder="০১৭১২-XXXXXX"
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      ঠিকানা / গ্রাম / ইউনিয়ন <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={requestDetails.address}
                      onChange={(e) => setRequestDetails({ ...requestDetails, address: e.target.value })}
                      placeholder="যেমন: আদবাড়িয়া, থানা, জেলা"
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      প্রয়োজনের সংক্ষিপ্ত বিবরণ
                    </label>
                    <textarea
                      rows={3}
                      value={requestDetails.notes}
                      onChange={(e) => setRequestDetails({ ...requestDetails, notes: e.target.value })}
                      placeholder="কী ধরণের সহায়তা প্রয়োজন..."
                      className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Send size={14} /> আবেদন জমা দিন
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
