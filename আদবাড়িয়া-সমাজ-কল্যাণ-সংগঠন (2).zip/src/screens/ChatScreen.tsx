import React, { useState, useEffect, useRef } from 'react';
import {
  MessageCircle,
  Send,
  Image as ImageIcon,
  CheckCheck,
  User,
  Sparkles,
  Smile,
  X,
} from 'lucide-react';
import { ChatMessage } from '../types';
import { useAuth } from '../context/AuthContext';
import { sendMessage } from '../services/firestoreService';
import { compressImage } from '../utils/imageUpload';

interface ChatScreenProps {
  messages: ChatMessage[];
  onRequireAuth: (hint: string) => void;
}

export const ChatScreen: React.FC<ChatScreenProps> = ({ messages, onRequireAuth }) => {
  const { currentUser, profile } = useAuth();
  const [inputText, setInputText] = useState('');
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleImagePick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const compressed = await compressImage(file, 800, 800, 0.7);
      setSelectedImage(compressed);
    } catch (err) {
      console.error(err);
    }
  };

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      onRequireAuth('চ্যাটে মেসেজ পাঠাতে লগইন প্রয়োজন');
      return;
    }

    if (!inputText.trim() && !selectedImage) return;

    setSending(true);
    try {
      await sendMessage({
        senderId: currentUser.uid,
        senderName: profile?.name || currentUser.displayName || 'সম্মানিত সদস্য',
        senderPhoto: profile?.photoURL || currentUser.photoURL || '',
        text: inputText.trim(),
        imageUrl: selectedImage || undefined,
      });

      setInputText('');
      setSelectedImage(null);
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] max-h-[800px] bg-slate-50 rounded-3xl border border-slate-200 shadow-sm overflow-hidden text-left font-['Hind_Siliguri']">
      {/* Chat Room Top Bar */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 text-white p-3.5 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-full bg-emerald-800 border border-emerald-600 flex items-center justify-center text-emerald-200">
            <MessageCircle size={18} />
          </div>
          <div>
            <h3 className="font-bold text-xs md:text-sm leading-tight flex items-center gap-1.5">
              <span>কল্যাণ সংসদ লাইভ চ্যাট</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </h3>
            <p className="text-[10px] text-emerald-300">
              সকল সদস্য ও স্বেচ্ছাসেবী উন্মুক্ত ইন্টারনেট কমিউনিকেশন
            </p>
          </div>
        </div>

        <div className="text-[10px] bg-white/10 px-2 py-0.5 rounded-full text-emerald-200 border border-white/10">
          রিয়েল-টাইম ক্লাউড
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-100/70">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <div className="w-16 h-16 rounded-full bg-emerald-100/60 text-emerald-700 flex items-center justify-center mb-3">
              <MessageCircle size={28} />
            </div>
            <h4 className="font-bold text-sm text-slate-700">এখনো কোনো মেসেজ আসেনি</h4>
            <p className="text-xs text-slate-500 max-w-xs mt-1">
              যেকোনো সদস্য নিচের মেসেজ বক্সে লিখে এই চ্যাট রুমে সরাসরি আলোচনা শুরু করতে পারেন।
            </p>
          </div>
        ) : (
          messages.map((msg) => {
            const isMe = currentUser?.uid === msg.senderId;

            return (
              <div
                key={msg.id}
                className={`flex items-end gap-2 ${isMe ? 'justify-end' : 'justify-start'}`}
              >
                {!isMe && (
                  msg.senderPhoto ? (
                    <img
                      src={msg.senderPhoto}
                      alt={msg.senderName}
                      className="w-7 h-7 rounded-full object-cover shrink-0 border border-slate-200 mb-1"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-emerald-800 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mb-1">
                      {msg.senderName?.charAt(0) || 'U'}
                    </div>
                  )
                )}

                <div
                  className={`max-w-[75%] rounded-2xl p-3 shadow-xs text-xs ${
                    isMe
                      ? 'bg-emerald-800 text-white rounded-br-none'
                      : 'bg-white text-slate-900 border border-slate-200 rounded-bl-none'
                  }`}
                >
                  {!isMe && (
                    <div className="text-[10px] font-bold text-emerald-800 mb-0.5">
                      {msg.senderName}
                    </div>
                  )}

                  {msg.imageUrl && (
                    <img
                      src={msg.imageUrl}
                      alt="Shared"
                      className="rounded-xl max-h-48 object-cover mb-1.5 w-full border border-black/10"
                    />
                  )}

                  {msg.text && (
                    <p className="leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>
                  )}

                  <div
                    className={`text-[9px] mt-1 flex items-center justify-end gap-1 ${
                      isMe ? 'text-emerald-200' : 'text-slate-400'
                    }`}
                  >
                    <span>
                      {msg.createdAt?.seconds
                        ? new Date(msg.createdAt.seconds * 1000).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })
                        : 'এখনই'}
                    </span>
                    {isMe && <CheckCheck size={11} className="text-emerald-300" />}
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Image Preview before sending */}
      {selectedImage && (
        <div className="p-2 bg-emerald-50 border-t border-emerald-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <img
              src={selectedImage}
              alt="Preview"
              className="w-10 h-10 rounded-lg object-cover border border-emerald-200"
            />
            <span className="text-[11px] text-emerald-800 font-medium">ছবি সংযুক্ত হয়েছে</span>
          </div>
          <button
            onClick={() => setSelectedImage(null)}
            className="p-1 rounded-full text-slate-400 hover:text-red-600"
          >
            <X size={16} />
          </button>
        </div>
      )}

      {/* Message Input Form */}
      <form
        onSubmit={handleSend}
        className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
      >
        <input
          type="file"
          ref={fileInputRef}
          accept="image/*"
          onChange={handleImagePick}
          className="hidden"
        />
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="p-2 rounded-xl text-slate-500 hover:text-emerald-800 hover:bg-slate-100 transition"
          title="ছবি সংযুক্ত করুন"
        >
          <ImageIcon size={18} />
        </button>

        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={currentUser ? 'আপনার মেসেজ লিখুন...' : 'মেসেজ পাঠাতে লগইন প্রয়োজন...'}
          disabled={!currentUser}
          className="flex-1 text-xs px-3.5 py-2.5 bg-slate-100 rounded-2xl border border-transparent focus:border-emerald-600 focus:bg-white focus:outline-none transition"
        />

        <button
          type="submit"
          disabled={sending || (!inputText.trim() && !selectedImage)}
          className={`p-2.5 rounded-2xl text-white transition flex items-center justify-center ${
            inputText.trim() || selectedImage
              ? 'bg-emerald-800 hover:bg-emerald-900 active:scale-95 shadow-md shadow-emerald-950/20 cursor-pointer'
              : 'bg-slate-300 cursor-not-allowed'
          }`}
          title="পাঠান"
        >
          <Send size={16} />
        </button>
      </form>
    </div>
  );
};
