import React, { useState } from 'react';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  PiggyBank,
  Plus,
  Calendar,
  CreditCard,
  CheckCircle,
  Clock,
  Send,
  Sparkles,
} from 'lucide-react';
import { Contribution, Donation, Expense } from '../types';
import { useAuth } from '../context/AuthContext';
import { addContribution, addDonation, addExpense } from '../services/firestoreService';

interface FinanceScreenProps {
  contributions: Contribution[];
  donations: Donation[];
  expenses: Expense[];
  summary: {
    totalContributions: number;
    totalDonations: number;
    totalExpenses: number;
    balance: number;
  };
  onRequireAuth: (hint: string) => void;
}

export const FinanceScreen: React.FC<FinanceScreenProps> = ({
  contributions,
  donations,
  expenses,
  summary,
  onRequireAuth,
}) => {
  const { currentUser, isAdmin, isSuperAdmin, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'contributions' | 'donations' | 'expenses'>('contributions');
  const [showDonationModal, setShowDonationModal] = useState(false);
  const [showAdminEntryModal, setShowAdminEntryModal] = useState<'contribution' | 'expense' | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Public Donation Form
  const [donorName, setDonorName] = useState(profile?.name || '');
  const [donorPhone, setDonorPhone] = useState(profile?.phone || '');
  const [donationAmount, setDonationAmount] = useState<number>(500);
  const [donationPurpose, setDonationPurpose] = useState('সাধারণ কল্যাণ তহবিল');
  const [donationMethod, setDonationMethod] = useState('বিকাশ / নগদ');
  const [donationTrxId, setDonationTrxId] = useState('');

  // Contribution Form (Admin)
  const [contribMemberName, setContribMemberName] = useState('');
  const [contribExpected, setContribExpected] = useState<number>(500);
  const [contribPaid, setContribPaid] = useState<number>(500);
  const [contribMonth, setContribMonth] = useState('অক্টোবর ২০২৬');
  const [contribMethod, setContribMethod] = useState('নগদ (Cash)');

  // Expense Form (Admin)
  const [expTitle, setExpTitle] = useState('');
  const [expCategory, setExpCategory] = useState('ত্রাণ ও খাদ্য সহায়তা');
  const [expAmount, setExpAmount] = useState<number>(1000);
  const [expVoucher, setExpVoucher] = useState('');

  const handleOpenDonate = () => {
    if (!currentUser) {
      onRequireAuth('তহবিলে অনুদান জমা দিতে লগইন বা নিবন্ধন করুন');
      return;
    }
    setShowDonationModal(true);
  };

  const handleSendDonation = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await addDonation({
        donorName: donorName || 'শুভাকাঙ্ক্ষী',
        phone: donorPhone,
        amount: Number(donationAmount) || 0,
        purpose: donationPurpose,
        paymentMethod: donationMethod,
        transactionId: donationTrxId,
        date: new Date().toISOString().split('T')[0],
        status: 'approved',
      });
      setShowDonationModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateContribution = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin && !isSuperAdmin) return;
    setSubmitting(true);
    try {
      const exp = Number(contribExpected) || 0;
      const paid = Number(contribPaid) || 0;
      await addContribution({
        memberName: contribMemberName,
        expectedAmount: exp,
        paidAmount: paid,
        dueAmount: Math.max(0, exp - paid),
        month: contribMonth,
        paymentDate: new Date().toISOString().split('T')[0],
        paymentMethod: contribMethod,
      });
      setShowAdminEntryModal(null);
      setContribMemberName('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCreateExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin && !isSuperAdmin) return;
    setSubmitting(true);
    try {
      await addExpense({
        title: expTitle,
        category: expCategory,
        amount: Number(expAmount) || 0,
        date: new Date().toISOString().split('T')[0],
        voucherNo: expVoucher,
      });
      setShowAdminEntryModal(null);
      setExpTitle('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Financial Summary Card */}
      <div className="bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 text-white rounded-3xl p-5 shadow-xl border border-emerald-800">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-xl bg-amber-400 text-slate-950">
              <PiggyBank size={18} />
            </span>
            <div>
              <h2 className="text-base font-bold">আদবাড়িয়া কল্যাণ তহবিল</h2>
              <p className="text-[11px] text-emerald-200">সম্পূর্ণ স্বচ্ছ হিসাব সংরক্ষণ ও হিসাব নিরীক্ষা</p>
            </div>
          </div>

          <button
            onClick={handleOpenDonate}
            className="px-3.5 py-1.5 bg-amber-400 hover:bg-amber-300 active:scale-95 text-slate-950 text-xs font-bold rounded-xl transition shadow flex items-center gap-1 cursor-pointer shrink-0"
          >
            <Plus size={14} /> অনুদান পাঠান
          </button>
        </div>

        {/* Current Balance Big Callout */}
        <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-4 border border-emerald-500/30 text-center mb-3">
          <span className="text-xs text-emerald-200 uppercase font-semibold tracking-wider">
            বর্তমান নিট তহবিল ব্যালেন্স
          </span>
          <div className="text-2xl md:text-3xl font-black text-amber-300 mt-1">
            ৳ {summary.balance.toLocaleString()}
          </div>
          <p className="text-[10px] text-emerald-200/80 mt-1">
            মোট চাঁদা + মোট অনুদান − মোট ব্যয় = বর্তমান ব্যালেন্স
          </p>
        </div>

        {/* Breakdown 3 tiles */}
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-emerald-900/60 rounded-xl p-2.5 border border-emerald-800/80">
            <span className="text-[10px] text-emerald-300 block">সদস্য চাঁদা (+)</span>
            <span className="text-xs font-bold text-white mt-0.5 block">
              ৳ {summary.totalContributions.toLocaleString()}
            </span>
          </div>
          <div className="bg-emerald-900/60 rounded-xl p-2.5 border border-emerald-800/80">
            <span className="text-[10px] text-emerald-300 block">সাধারণ অনুদান (+)</span>
            <span className="text-xs font-bold text-amber-300 mt-0.5 block">
              ৳ {summary.totalDonations.toLocaleString()}
            </span>
          </div>
          <div className="bg-emerald-900/60 rounded-xl p-2.5 border border-emerald-800/80">
            <span className="text-[10px] text-rose-300 block">মোট ব্যয় (−)</span>
            <span className="text-xs font-bold text-rose-200 mt-0.5 block">
              ৳ {summary.totalExpenses.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-2xl bg-slate-200/80 p-1">
        <button
          onClick={() => setActiveTab('contributions')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'contributions'
              ? 'bg-white text-emerald-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          সদস্য চাঁদা ({contributions.length})
        </button>
        <button
          onClick={() => setActiveTab('donations')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'donations'
              ? 'bg-white text-emerald-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          সাধারণ অনুদান ({donations.length})
        </button>
        <button
          onClick={() => setActiveTab('expenses')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'expenses'
              ? 'bg-white text-emerald-950 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          ব্যয় ও ভাউচার ({expenses.length})
        </button>
      </div>

      {/* Admin Quick Entry Buttons */}
      {(isAdmin || isSuperAdmin) && (
        <div className="flex gap-2 justify-end">
          {activeTab === 'contributions' && (
            <button
              onClick={() => setShowAdminEntryModal('contribution')}
              className="px-3 py-1.5 bg-emerald-800 hover:bg-emerald-900 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Plus size={14} /> সদস্য চাঁদা লিপিবদ্ধ করুন
            </button>
          )}
          {activeTab === 'expenses' && (
            <button
              onClick={() => setShowAdminEntryModal('expense')}
              className="px-3 py-1.5 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-bold transition flex items-center gap-1 shadow-xs cursor-pointer"
            >
              <Plus size={14} /> নতুন ব্যয় ভাউচার যোগ করুন
            </button>
          )}
        </div>
      )}

      {/* Tab 1: Member Contributions */}
      {activeTab === 'contributions' && (
        <div className="space-y-2.5">
          {contributions.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <Wallet size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">কোনো সদস্য চাঁদা পাওয়া যায়নি</h4>
              <p className="text-xs text-slate-400 mt-1">
                ফায়ারবেসে চাঁদার হিসাব যুক্ত হলে এখানে সদস্য অনুযায়ী বিস্তারিত প্রদর্শিত হবে।
              </p>
            </div>
          ) : (
            contributions.map((c) => (
              <div
                key={c.id}
                className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-xs flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-slate-900">{c.memberName}</h4>
                    <span className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.2 rounded font-medium">
                      {c.month}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-3">
                    <span>প্রত্যাশিত: ৳ {c.expectedAmount}</span>
                    <span>পরিশোধিত: <strong className="text-emerald-700 font-bold">৳ {c.paidAmount}</strong></span>
                    {c.dueAmount > 0 && (
                      <span className="text-rose-600 font-bold">বকেয়া: ৳ {c.dueAmount}</span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    পদ্ধতি: {c.paymentMethod} • তারিখ: {c.paymentDate}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    c.dueAmount === 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {c.dueAmount === 0 ? 'পরিশোধিত' : 'আংশিক বকেয়া'}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 2: Donations */}
      {activeTab === 'donations' && (
        <div className="space-y-2.5">
          {donations.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <PiggyBank size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">কোনো অনুদান তালিকাভুক্ত নেই</h4>
              <p className="text-xs text-slate-400 mt-1">
                উপরে &quot;অনুদান পাঠান&quot; বাটনে চাপ দিয়ে যেকোনো শুভাকাঙ্ক্ষী সহায়তা পাঠাতে পারেন।
              </p>
            </div>
          ) : (
            donations.map((d) => (
              <div
                key={d.id}
                className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-xs flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-slate-900">{d.donorName}</h4>
                    <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.2 rounded">
                      {d.purpose}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    পদ্ধতি: {d.paymentMethod} {d.transactionId && `(TrxID: ${d.transactionId})`} • তারিখ: {d.date}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-sm font-extrabold text-emerald-700">
                    ৳ {d.amount.toLocaleString()}
                  </div>
                  <span className="text-[9px] text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded font-medium">
                    যাচাইকৃত
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Tab 3: Expenses */}
      {activeTab === 'expenses' && (
        <div className="space-y-2.5">
          {expenses.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <TrendingDown size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">কোনো ব্যয়ের হিসাব তালিকাভুক্ত নেই</h4>
              <p className="text-xs text-slate-400 mt-1">
                সংগঠনের সকল সেবা ও ত্রাণ বিতরণের ব্যয় ভাউচার এখানে লিপিবদ্ধ করা হয়।
              </p>
            </div>
          ) : (
            expenses.map((e) => (
              <div
                key={e.id}
                className="bg-white rounded-2xl p-3.5 border border-slate-200/80 shadow-xs flex items-center justify-between gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-slate-900">{e.title}</h4>
                    <span className="text-[10px] bg-rose-100 text-rose-800 font-bold px-2 py-0.2 rounded">
                      {e.category}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1">
                    ভাউচার নং: {e.voucherNo || 'N/A'} • তারিখ: {e.date}
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <div className="text-sm font-extrabold text-rose-600">
                    − ৳ {e.amount.toLocaleString()}
                  </div>
                  <span className="text-[9px] text-slate-400">অনুমোদিত ব্যয়</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Public Donation Modal */}
      {showDonationModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <PiggyBank className="text-emerald-700" size={18} />
                সংগঠনের তহবিলে অনুদান পাঠান
              </h3>
              <button
                onClick={() => setShowDonationModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSendDonation} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  আপনার নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="দাতা বা শুভাকাঙ্ক্ষীর নাম"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    অনুদানের পরিমাণ (টাকা) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min={10}
                    value={donationAmount}
                    onChange={(e) => setDonationAmount(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    মোবাইল নম্বর
                  </label>
                  <input
                    type="tel"
                    value={donorPhone}
                    onChange={(e) => setDonorPhone(e.target.value)}
                    placeholder="০১৭১২-XXXXXX"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  অনুদানের খাত / উদ্দেশ্য
                </label>
                <select
                  value={donationPurpose}
                  onChange={(e) => setDonationPurpose(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-white"
                >
                  <option value="সাধারণ কল্যাণ তহবিল">সাধারণ কল্যাণ তহবিল</option>
                  <option value="জরুরি চিকিৎসা তহবিল">জরুরি চিকিৎসা তহবিল</option>
                  <option value="দরিদ্র খাদ্য সহায়তা">দরিদ্র খাদ্য সহায়তা</option>
                  <option value="শীতবস্ত্র বিতরণ">শীতবস্ত্র বিতরণ</option>
                  <option value="শিক্ষা উপবৃত্তি">শিক্ষা উপবৃত্তি</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    পেমেন্ট মাধ্যম
                  </label>
                  <select
                    value={donationMethod}
                    onChange={(e) => setDonationMethod(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-white"
                  >
                    <option value="বিকাশ (bKash)">বিকাশ (bKash)</option>
                    <option value="নগদ (Nagad)">নগদ (Nagad)</option>
                    <option value="রকেট (Rocket)">রকেট (Rocket)</option>
                    <option value="ব্যাংক ট্রান্সফার">ব্যাংক ট্রান্সফার</option>
                    <option value="সরাসরি নগদ (Cash)">সরাসরি নগদ (Cash)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ট্রানজেকশন আইডি (ঐচ্ছিক)
                  </label>
                  <input
                    type="text"
                    value={donationTrxId}
                    onChange={(e) => setDonationTrxId(e.target.value)}
                    placeholder="TrxID..."
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                {submitting ? 'সংরক্ষণ হচ্ছে...' : 'অনুদান রেকর্ড করুন'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Admin Contribution Modal */}
      {showAdminEntryModal === 'contribution' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">সদস্য চাঁদা এন্ট্রি ফরম</h3>
              <button onClick={() => setShowAdminEntryModal(null)} className="text-slate-400 font-bold">✕</button>
            </div>
            <form onSubmit={handleCreateContribution} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">সদস্যের নাম *</label>
                <input
                  type="text"
                  required
                  value={contribMemberName}
                  onChange={(e) => setContribMemberName(e.target.value)}
                  placeholder="সদস্যের নাম"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">নির্ধারিত চাঁদা (৳)</label>
                  <input
                    type="number"
                    value={contribExpected}
                    onChange={(e) => setContribExpected(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">প্রদত্ত চাঁদা (৳)</label>
                  <input
                    type="number"
                    value={contribPaid}
                    onChange={(e) => setContribPaid(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">মাস</label>
                <input
                  type="text"
                  value={contribMonth}
                  onChange={(e) => setContribMonth(e.target.value)}
                  placeholder="অক্টোবর ২০২৬"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-emerald-800 text-white font-bold text-xs rounded-xl"
              >
                সংরক্ষণ করুন
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Admin Expense Modal */}
      {showAdminEntryModal === 'expense' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-rose-100">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900">ব্যয় ভাউচার এন্ট্রি ফরম</h3>
              <button onClick={() => setShowAdminEntryModal(null)} className="text-slate-400 font-bold">✕</button>
            </div>
            <form onSubmit={handleCreateExpense} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ব্যয়ের বিবরণ *</label>
                <input
                  type="text"
                  required
                  value={expTitle}
                  onChange={(e) => setExpTitle(e.target.value)}
                  placeholder="যেমন: কম্বল ক্রয় ও পরিবহন খরচ"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">ব্যয়ের খাত</label>
                  <input
                    type="text"
                    value={expCategory}
                    onChange={(e) => setExpCategory(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">পরিমাণ (৳) *</label>
                  <input
                    type="number"
                    required
                    value={expAmount}
                    onChange={(e) => setExpAmount(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">ভাউচার / রসিদ নং</label>
                <input
                  type="text"
                  value={expVoucher}
                  onChange={(e) => setExpVoucher(e.target.value)}
                  placeholder="VCH-2026-001"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-rose-700 text-white font-bold text-xs rounded-xl"
              >
                ব্যয় অনুমোদন ও সংরক্ষণ
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
