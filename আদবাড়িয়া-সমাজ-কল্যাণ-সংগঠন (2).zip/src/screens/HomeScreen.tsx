import React from 'react';
import {
  Heart,
  Droplet,
  Flame,
  Wallet,
  Users,
  Megaphone,
  ArrowRight,
  PhoneCall,
  Clock,
  MapPin,
  Sparkles,
  Download,
  AlertTriangle,
} from 'lucide-react';
import { Logo } from '../components/Logo';
import { ServiceCategory, BloodRequest, HumanitarianActivity, Notice } from '../types';
import { AppTab } from '../components/BottomNav';

interface HomeScreenProps {
  services: ServiceCategory[];
  bloodRequests: BloodRequest[];
  activities: HumanitarianActivity[];
  notices: Notice[];
  totalMembers: number;
  currentBalance: number;
  onNavigateTab: (tab: AppTab) => void;
  onRequestBlood: () => void;
  onDonate: () => void;
  onJoinVolunteer: () => void;
  onDownloadAndroidZip: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  services,
  bloodRequests,
  activities,
  notices,
  totalMembers,
  currentBalance,
  onNavigateTab,
  onRequestBlood,
  onDonate,
  onJoinVolunteer,
  onDownloadAndroidZip,
}) => {
  // Urgent blood requests
  const urgentRequests = bloodRequests.filter(
    (b) => (b.urgency === 'critical' || b.urgency === 'emergency') && b.status === 'pending'
  );

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Prominent Instant Download Card */}
      <div className="bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-600 text-white rounded-2xl p-3.5 shadow-md border-2 border-emerald-400 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-white text-emerald-800 flex items-center justify-center shrink-0 shadow">
            <Download size={20} />
          </div>
          <div>
            <h3 className="font-extrabold text-xs md:text-sm leading-tight text-white">
              Our Goal — ইনস্টলযোগ্য release.apk
            </h3>
            <p className="text-[11px] font-medium text-emerald-100">
              ফোনে সরাসরি ইনস্টল করতে নিচের বাটনে চাপ দিন
            </p>
          </div>
        </div>
        <button
          onClick={onDownloadAndroidZip}
          className="px-3.5 py-2 bg-white hover:bg-emerald-50 active:scale-95 text-emerald-900 font-extrabold text-xs rounded-xl shadow transition shrink-0 cursor-pointer flex items-center gap-1.5"
        >
          <Download size={14} /> ডাউনলোড APK
        </button>
      </div>

      {/* Hero Organization Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-950 via-emerald-900 to-emerald-950 text-white p-6 shadow-xl border border-emerald-800/60">
        {/* Subtle decorative background circles */}
        <div className="absolute -top-16 -right-16 w-52 h-52 rounded-full bg-emerald-600/15 blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-52 h-52 rounded-full bg-amber-500/10 blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center text-center">
          <div className="p-1.5 rounded-full bg-emerald-900/80 border-2 border-amber-400/40 shadow-inner mb-3">
            <Logo size={100} />
          </div>

          <h2 className="text-xl md:text-2xl font-black tracking-tight text-white mb-1">
            আদবাড়িয়া সমাজ কল্যাণ সংগঠন
          </h2>
          
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-sm border border-emerald-400/30 text-amber-300 text-xs font-semibold mb-3">
            <span>মানুষের পাশে, মানবতার জন্য</span>
          </div>

          <p className="text-xs text-emerald-100/90 max-w-md leading-relaxed mb-4">
            মানবিক সাহায্য, জরুরি রক্তদান, অসচ্ছল পরিবার পুনর্বাসন ও সমাজসেবামূলক কার্যক্রমে নিবেদিত একটি অরাজনৈতিক সামাজিক কল্যাণ সংগঠন।
          </p>

          {/* Quick Action Badges */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 w-full pt-1">
            <button
              onClick={onRequestBlood}
              className="px-3 py-2.5 rounded-2xl bg-red-600/90 hover:bg-red-700 active:scale-95 text-white text-xs font-bold transition shadow-md flex items-center justify-center gap-1.5 border border-red-500"
            >
              <Droplet size={15} /> রক্তের আবেদন
            </button>
            <button
              onClick={onDonate}
              className="px-3 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-600 active:scale-95 text-slate-950 text-xs font-bold transition shadow-md flex items-center justify-center gap-1.5 border border-amber-400"
            >
              <Wallet size={15} /> তহবিলে অনুদান
            </button>
            <button
              onClick={onJoinVolunteer}
              className="px-3 py-2.5 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white text-xs font-bold transition shadow-md flex items-center justify-center gap-1.5 border border-emerald-600"
            >
              <Heart size={15} /> স্বেচ্ছাসেবী হন
            </button>
            <button
              onClick={onDownloadAndroidZip}
              className="px-3 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-900 active:scale-95 text-white text-xs font-bold transition shadow-md flex items-center justify-center gap-1.5 border border-slate-700"
            >
              <Download size={15} /> APK সোর্স কোড
            </button>
          </div>
        </div>
      </div>

      {/* Urgent Blood Alert (if any active) */}
      {urgentRequests.length > 0 && (
        <div className="rounded-2xl bg-red-50 border-2 border-red-300 p-3.5 shadow-sm">
          <div className="flex items-center gap-2 text-red-700 font-bold text-sm mb-1.5">
            <AlertTriangle size={18} className="animate-pulse" />
            <span>জরুরি রক্তের আবেদন ({urgentRequests.length}টি সক্রিয়)</span>
          </div>
          <div className="space-y-2">
            {urgentRequests.slice(0, 2).map((req) => (
              <div
                key={req.id}
                className="bg-white rounded-xl p-2.5 border border-red-200 flex items-center justify-between gap-3 shadow-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-red-600 text-white font-extrabold text-xs">
                      {req.bloodGroup}
                    </span>
                    <span className="font-bold text-xs text-slate-900">{req.patientName}</span>
                    <span className="text-[10px] text-red-600 font-bold bg-red-100 px-1.5 py-0.2 rounded">
                      {req.units} ব্যাগ প্রয়োজন
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2">
                    <span className="flex items-center gap-0.5"><MapPin size={11} /> {req.hospital}, {req.location}</span>
                  </div>
                </div>
                <a
                  href={`tel:${req.contact}`}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow-sm shrink-0"
                >
                  <PhoneCall size={13} /> কল করুন
                </a>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Live Statistics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <Heart size={20} />
          </div>
          <div>
            <div className="text-base font-black text-slate-900">{services.length} টি</div>
            <div className="text-[11px] text-slate-500">সক্রিয় সেবা</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
            <Flame size={20} />
          </div>
          <div>
            <div className="text-base font-black text-slate-900">{activities.length} টি</div>
            <div className="text-[11px] text-slate-500">মানবিক কার্যক্রম</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center shrink-0">
            <Users size={20} />
          </div>
          <div>
            <div className="text-base font-black text-slate-900">{totalMembers} জন</div>
            <div className="text-[11px] text-slate-500">নিবন্ধিত সদস্য</div>
          </div>
        </div>

        <div className="bg-white rounded-2xl p-3 border border-slate-200/80 shadow-xs flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
            <Wallet size={20} />
          </div>
          <div>
            <div className="text-base font-black text-emerald-700">৳ {currentBalance.toLocaleString()}</div>
            <div className="text-[11px] text-slate-500">বর্তমান তহবিল</div>
          </div>
        </div>
      </div>

      {/* Humanitarian Services Grid */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-bold text-sm text-slate-900">মানবিক সেবাসমূহ</h3>
            <p className="text-[11px] text-slate-500">সংগঠনের প্রধান সেবামূলক কার্যক্রমসমূহ</p>
          </div>
          <button
            onClick={() => onNavigateTab('services')}
            className="text-xs text-emerald-700 font-bold flex items-center gap-0.5 hover:underline"
          >
            সব দেখুন <ArrowRight size={13} />
          </button>
        </div>

        {services.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-xs">
            এখনো কোনো সেবা তালিকাভুক্ত করা হয়নি। অ্যাডমিন প্যানেল থেকে যোগ করুন।
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
            {services.slice(0, 8).map((srv) => (
              <div
                key={srv.id}
                onClick={() => onNavigateTab('services')}
                className="p-3 rounded-2xl border border-slate-100 bg-slate-50/60 hover:bg-emerald-50/50 hover:border-emerald-200 transition cursor-pointer flex flex-col justify-between"
              >
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-white mb-2 shadow-xs"
                  style={{ backgroundColor: srv.color || '#0D522C' }}
                >
                  <Heart size={16} />
                </div>
                <div>
                  <h4 className="font-bold text-xs text-slate-900 leading-tight mb-0.5">{srv.title}</h4>
                  <p className="text-[10px] text-slate-500 line-clamp-2 leading-relaxed">{srv.description}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Humanitarian Activities Preview */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200/80 shadow-xs">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h3 className="font-bold text-sm text-slate-900">সাম্প্রতিক কার্যক্রম</h3>
            <p className="text-[11px] text-slate-500">বাস্তবায়িত ও চলমান মানবসেবামূলক প্রজেক্ট</p>
          </div>
          <button
            onClick={() => onNavigateTab('activities')}
            className="text-xs text-emerald-700 font-bold flex items-center gap-0.5 hover:underline"
          >
            সব দেখুন <ArrowRight size={13} />
          </button>
        </div>

        {activities.length === 0 ? (
          <div className="py-8 text-center text-slate-400 text-xs">
            বর্তমানে কোনো কার্যক্রম যুক্ত নেই। নতুন কার্যক্রম অ্যাডমিন থেকে প্রকাশ করা হবে।
          </div>
        ) : (
          <div className="space-y-2.5">
            {activities.slice(0, 3).map((act) => (
              <div
                key={act.id}
                onClick={() => onNavigateTab('activities')}
                className="p-3 rounded-2xl border border-slate-100 hover:border-emerald-200 bg-slate-50/40 hover:bg-emerald-50/20 transition cursor-pointer flex gap-3 items-center"
              >
                {act.imageUrl ? (
                  <img
                    src={act.imageUrl}
                    alt={act.title}
                    className="w-16 h-16 rounded-xl object-cover shrink-0 border border-slate-200"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center shrink-0">
                    <Flame size={24} />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded ${
                      act.status === 'completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {act.status === 'completed' ? 'সম্পন্ন' : 'চলমান'}
                    </span>
                    <span className="text-[11px] text-slate-400">{act.date}</span>
                  </div>
                  <h4 className="font-bold text-xs text-slate-900 truncate mt-1">{act.title}</h4>
                  <p className="text-[11px] text-slate-500 truncate">{act.location}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Latest Notice Ticker */}
      {notices.length > 0 && (
        <div className="bg-amber-50/80 rounded-2xl p-3.5 border border-amber-200 flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-500 text-slate-950 shrink-0">
            <Megaphone size={16} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-amber-800 bg-amber-100 px-1.5 py-0.2 rounded">
                সর্বশেষ নোটিশ
              </span>
              <span className="text-[10px] text-amber-700">{notices[0].date}</span>
            </div>
            <h4 className="text-xs font-bold text-slate-900 mt-1">{notices[0].title}</h4>
            <p className="text-[11px] text-slate-600 line-clamp-2 mt-0.5 leading-relaxed">
              {notices[0].content}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
