import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Users,
  Heart,
  Droplet,
  Flame,
  PiggyBank,
  Plus,
  RefreshCw,
  Sparkles,
  Download,
  CheckCircle2,
  AlertCircle,
  FolderInput,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  importDefaultServices,
  subscribeUsers,
  updateUserRole,
} from '../services/firestoreService';
import {
  ServiceCategory,
  HumanitarianActivity,
  BloodRequest,
  OrgMember,
  OrgVolunteer,
  UserProfile,
} from '../types';

interface AdminScreenProps {
  services: ServiceCategory[];
  activities: HumanitarianActivity[];
  bloodRequests: BloodRequest[];
  members: OrgMember[];
  volunteers: OrgVolunteer[];
  summary: {
    totalContributions: number;
    totalDonations: number;
    totalExpenses: number;
    balance: number;
  };
  onNavigateTab: (tab: any) => void;
}

export const AdminScreen: React.FC<AdminScreenProps> = ({
  services,
  activities,
  bloodRequests,
  members,
  volunteers,
  summary,
  onNavigateTab,
}) => {
  const { isSuperAdmin, isAdmin, currentUser, profile } = useAuth();
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [importing, setImporting] = useState(false);
  const [importMessage, setImportMessage] = useState<string | null>(null);

  useEffect(() => {
    const unsub = subscribeUsers((users) => {
      setUsersList(users);
    });
    return unsub;
  }, []);

  const handleImportCategories = async () => {
    setImporting(true);
    setImportMessage(null);
    try {
      const result = await importDefaultServices();
      if (result) {
        setImportMessage('১২টি প্রধান মানবিক সেবা ক্যাটাগরি সফলভাবে ফায়ারবেসে ইমপোর্ট হয়েছে!');
      } else {
        setImportMessage('সেবাসমূহ ইতিমধ্যে ফায়ারবেসে বিদ্যমান রয়েছে।');
      }
    } catch (err: any) {
      setImportMessage(`ত্রুটি: ${err.message}`);
    } finally {
      setImporting(false);
    }
  };

  const handleToggleAdminRole = async (user: UserProfile) => {
    if (!isSuperAdmin) {
      alert('শুধুমাত্র সুপার অ্যাডমিন নতুন অ্যাডমিন নিয়োগ বা অপসারণ করতে পারেন।');
      return;
    }
    const newRole = user.role === 'admin' ? 'member' : 'admin';
    const confirmMsg =
      newRole === 'admin'
        ? `আপনি কি নিশ্চিত যে "${user.name}" কে অ্যাডমিন মর্যাদা দিতে চান?`
        : `আপনি কি "${user.name}" এর অ্যাডমিন মর্যাদা বাতিল করতে চান?`;

    if (confirm(confirmMsg)) {
      await updateUserRole(user.uid, newRole, newRole === 'admin' ? ['manage_services', 'manage_finances'] : []);
    }
  };

  if (!isAdmin && !isSuperAdmin) {
    return (
      <div className="py-20 text-center font-['Hind_Siliguri']">
        <AlertCircle size={48} className="text-red-500 mx-auto mb-2" />
        <h3 className="font-bold text-base text-slate-800">অ্যাক্সেস সংরক্ষিত</h3>
        <p className="text-xs text-slate-500 mt-1">
          এই প্যানেল শুধুমাত্র অনুমোদিত অ্যাডমিন এবং সুপার অ্যাডমিনের জন্য সংরক্ষিত।
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 text-white rounded-3xl p-5 shadow-xl border border-emerald-800">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="p-1.5 rounded-xl bg-amber-400 text-slate-950 font-bold">
                <ShieldCheck size={18} />
              </span>
              <h2 className="text-lg font-bold">
                {isSuperAdmin ? 'সুপার অ্যাডমিন কন্ট্রোল প্যানেল' : 'অ্যাডমিন ড্যাশবোর্ড'}
              </h2>
            </div>
            <p className="text-xs text-emerald-200">
              রিয়েল-টাইম ক্লাউড ফায়ারবেস ডেটা ম্যানেজমেন্ট ও সিকিউরিটি কন্ট্রোল
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/40 px-2.5 py-1 rounded-full font-bold">
              UID: {currentUser?.uid.slice(0, 8)}...
            </span>
          </div>
        </div>
      </div>

      {/* 1-Click Import / Setup Action */}
      <div className="bg-amber-50 rounded-2xl p-4 border border-amber-200 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
        <div>
          <h4 className="font-bold text-xs text-amber-950 flex items-center gap-1.5">
            <FolderInput size={16} className="text-amber-700" />
            প্রাথমিক মানবিক সেবা ক্যাটাগরি ইমপোর্ট করুন
          </h4>
          <p className="text-[11px] text-amber-800/90 mt-0.5">
            রক্তদান, খাদ্য বিতরণ, শীতবস্ত্র, চিকিৎসাসহ ১২টি সেবা ফায়ারবেসে ১-ক্লিকে ইনস্টল করুন।
          </p>
          {importMessage && (
            <p className="text-[11px] font-bold text-emerald-800 mt-1.5 flex items-center gap-1">
              <CheckCircle2 size={13} /> {importMessage}
            </p>
          )}
        </div>

        <button
          onClick={handleImportCategories}
          disabled={importing}
          className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow flex items-center gap-1.5 shrink-0 cursor-pointer"
        >
          {importing ? (
            <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
          ) : (
            <Sparkles size={14} />
          )}
          সেবাসমূহ ইমপোর্ট
        </button>
      </div>

      {/* Real Statistics Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">মোট সদস্য</span>
          <span className="text-lg font-black text-slate-900 mt-0.5 block">{members.length} জন</span>
        </div>
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">সক্রিয় স্বেচ্ছাসেবী</span>
          <span className="text-lg font-black text-slate-900 mt-0.5 block">{volunteers.length} জন</span>
        </div>
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">রক্তের আবেদন</span>
          <span className="text-lg font-black text-red-600 mt-0.5 block">{bloodRequests.length} টি</span>
        </div>
        <div className="bg-white rounded-2xl p-3 border border-slate-200 shadow-xs">
          <span className="text-[11px] text-slate-500 block">তহবিল ব্যালেন্স</span>
          <span className="text-lg font-black text-emerald-700 mt-0.5 block">
            ৳ {summary.balance.toLocaleString()}
          </span>
        </div>
      </div>

      {/* Quick Navigation Action Grid */}
      <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs">
        <h3 className="font-bold text-sm text-slate-900 mb-2.5">দ্রুত প্রশাসনিক কাজ (Quick Actions)</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => onNavigateTab('services')}
            className="p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 text-slate-800 text-xs font-bold border border-slate-200 text-center transition"
          >
            + সেবা যুক্ত করুন
          </button>
          <button
            onClick={() => onNavigateTab('activities')}
            className="p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 text-slate-800 text-xs font-bold border border-slate-200 text-center transition"
          >
            + কার্যক্রম যুক্ত করুন
          </button>
          <button
            onClick={() => onNavigateTab('notices')}
            className="p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 text-slate-800 text-xs font-bold border border-slate-200 text-center transition"
          >
            + নোটিশ প্রকাশ করুন
          </button>
          <button
            onClick={() => onNavigateTab('finance')}
            className="p-3 rounded-2xl bg-slate-50 hover:bg-emerald-50 text-slate-800 text-xs font-bold border border-slate-200 text-center transition"
          >
            + চাঁদা / ব্যয় হিসাব
          </button>
        </div>
      </div>

      {/* Role Management (Super Admin Exclusive) */}
      {isSuperAdmin && (
        <div className="bg-white rounded-3xl p-4 border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-bold text-sm text-slate-900">
                ব্যবহারকারী ও অ্যাডমিন পরিচালনা (RBAC)
              </h3>
              <p className="text-[11px] text-slate-500">
                সুপার অ্যাডমিন নতুন অ্যাডমিন যুক্ত বা সাধারণ সদস্যে পরিবর্তন করতে পারেন
              </p>
            </div>
            <span className="text-xs bg-emerald-100 text-emerald-800 font-bold px-2 py-0.5 rounded-full">
              মোট একাউন্ট: {usersList.length}
            </span>
          </div>

          <div className="space-y-2">
            {usersList.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">এখনো কোনো ব্যবহারকারী তালিকাভুক্ত নেই</p>
            ) : (
              usersList.map((u) => {
                const isSuper = u.role === 'super_admin' || u.uid === 'SI5nqpVS0oYKv9ZFDWV6zNVnK5v1';
                return (
                  <div
                    key={u.uid}
                    className="p-3 rounded-2xl border border-slate-100 flex items-center justify-between gap-3 bg-slate-50/50"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900">{u.name}</span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                            isSuper
                              ? 'bg-amber-400 text-slate-950'
                              : u.role === 'admin'
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-200 text-slate-700'
                          }`}
                        >
                          {isSuper ? 'সুপার অ্যাডমিন' : u.role === 'admin' ? 'অ্যাডমিন' : 'সদস্য'}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        {u.email} • {u.phone || 'মোবাইল যুক্ত নেই'}
                      </div>
                    </div>

                    {!isSuper && (
                      <button
                        onClick={() => handleToggleAdminRole(u)}
                        className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                          u.role === 'admin'
                            ? 'bg-rose-100 hover:bg-rose-200 text-rose-800'
                            : 'bg-emerald-800 hover:bg-emerald-900 text-white'
                        }`}
                      >
                        {u.role === 'admin' ? 'অ্যাডমিন বাতিল' : 'অ্যাডমিন বানান'}
                      </button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
