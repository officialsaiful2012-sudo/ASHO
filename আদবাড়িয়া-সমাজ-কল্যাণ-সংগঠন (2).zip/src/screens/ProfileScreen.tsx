import React, { useState } from 'react';
import {
  User,
  Mail,
  Phone,
  ShieldCheck,
  LogOut,
  Download,
  CheckCircle,
  MapPin,
  Calendar,
  Lock,
  Droplet,
  Smartphone,
  ExternalLink,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Logo } from '../components/Logo';
import { ImageUploadInput } from '../components/ImageUploadInput';

interface ProfileScreenProps {
  onDownloadAndroidZip: () => void;
  onOpenAuth: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  onDownloadAndroidZip,
  onOpenAuth,
}) => {
  const { currentUser, profile, logout, isSuperAdmin, isAdmin } = useAuth();
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      await onDownloadAndroidZip();
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Profile Card if Logged In */}
      {currentUser && profile ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs">
          {/* Header Cover */}
          <div className="bg-gradient-to-r from-emerald-950 via-emerald-900 to-emerald-950 p-6 text-white text-center relative">
            <div className="w-20 h-20 rounded-full mx-auto border-4 border-amber-400/80 overflow-hidden shadow-lg bg-emerald-950 flex items-center justify-center">
              {profile.photoURL ? (
                <img
                  src={profile.photoURL}
                  alt={profile.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <Logo size={70} />
              )}
            </div>

            <h2 className="text-lg font-bold mt-2">{profile.name}</h2>
            <div className="flex items-center justify-center gap-2 mt-1">
              <span
                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                  isSuperAdmin
                    ? 'bg-amber-400 text-slate-950'
                    : isAdmin
                    ? 'bg-emerald-400 text-slate-950'
                    : 'bg-white/20 text-white'
                }`}
              >
                {isSuperAdmin
                  ? 'সুপার অ্যাডমিন'
                  : isAdmin
                  ? 'অ্যাডমিন'
                  : 'সংগঠনের সদস্য'}
              </span>
            </div>
          </div>

          {/* Details list */}
          <div className="p-5 space-y-3 text-xs divide-y divide-slate-100">
            <div className="flex items-center justify-between pt-1">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Mail size={15} /> ইমেইল ঠিকানা
              </span>
              <span className="font-semibold text-slate-800">{profile.email}</span>
            </div>

            <div className="flex items-center justify-between pt-3">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Phone size={15} /> মোবাইল নম্বর
              </span>
              <span className="font-semibold text-slate-800">{profile.phone || 'যুক্ত নেই'}</span>
            </div>

            <div className="flex items-center justify-between pt-3">
              <span className="text-slate-500 flex items-center gap-1.5">
                <ShieldCheck size={15} /> অ্যাকাউন্ট স্ট্যাটাস
              </span>
              <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                সক্রিয় (Active)
              </span>
            </div>

            <div className="flex items-center justify-between pt-3">
              <span className="text-slate-500">ফায়ারবেস ইউজার আইডি (UID)</span>
              <span className="font-mono text-[10px] text-slate-600 truncate max-w-[150px]">
                {currentUser.uid}
              </span>
            </div>

            <div className="pt-4 flex justify-center">
              <button
                onClick={logout}
                className="px-5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl text-xs transition flex items-center gap-1.5 cursor-pointer border border-rose-200"
              >
                <LogOut size={14} /> লগআউট করুন
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Guest prompt to login */
        <div className="bg-white rounded-3xl p-6 border border-slate-200/90 text-center shadow-xs">
          <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-900 mx-auto flex items-center justify-center mb-3">
            <User size={30} />
          </div>
          <h3 className="font-bold text-base text-slate-900">লগইন বা একাউন্ট খুলুন</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
            রক্তদান সেবা, স্বেচ্ছাসেবা কার্যক্রম ও সদস্য মেসেজিং ফিচারে অংশ নিতে অনুগ্রহ করে লগইন করুন।
          </p>
          <button
            onClick={onOpenAuth}
            className="mt-4 px-6 py-2.5 bg-emerald-800 hover:bg-emerald-900 active:scale-95 text-white font-bold text-xs rounded-xl transition shadow cursor-pointer"
          >
            লগইন / নিবন্ধন করুন
          </button>
        </div>
      )}

      {/* Android Studio Native Build Card */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-3xl p-5 border border-slate-800 shadow-md">
        <div className="flex items-start justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Smartphone className="text-emerald-400" size={18} />
              <h3 className="font-bold text-sm text-white">
                নেটিভ অ্যান্ড্রয়েড স্টুডিও প্রজেক্ট (APK)
              </h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-md">
              প্রজেক্টটিতে রয়েছে Kotlin, Jetpack Compose, Material 3, ViewModel, Repository এবং প্রস্তুতকৃত{' '}
              <code className="text-amber-300 font-mono text-[11px]">app/google-services.json</code>। আপনি সরাসরি Android Studio দিয়ে রান ও APK জেনারেট করতে পারবেন।
            </p>
          </div>

          <button
            onClick={handleDownload}
            disabled={downloading}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold rounded-xl transition shadow flex items-center gap-1.5 shrink-0 cursor-pointer"
          >
            {downloading ? (
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <Download size={15} />
            )}
            প্রজেক্ট ZIP ডাউনলোড
          </button>
        </div>
      </div>

      {/* Organization Credentials and Info */}
      <div className="bg-emerald-50/70 rounded-3xl p-4 border border-emerald-200 text-xs text-emerald-950 space-y-1">
        <div className="font-bold text-emerald-900 flex items-center gap-1.5">
          <Logo size={22} />
          <span>আদবাড়িয়া সমাজ কল্যাণ সংগঠন</span>
        </div>
        <p className="text-[11px] text-emerald-800">
          মূলমন্ত্র: &ldquo;মানুষের পাশে, মানবতার জন্য&rdquo;
        </p>
        <p className="text-[10px] text-emerald-700">
          প্রকল্প আইডি: <code className="font-mono">asho-c9c33</code> (Google Services Ready)
        </p>
      </div>
    </div>
  );
};
