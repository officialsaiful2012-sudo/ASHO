import React, { useState } from 'react';
import {
  Droplet,
  Plus,
  Phone,
  Search,
  Calendar,
  MapPin,
  Clock,
  UserCheck,
  CheckCircle,
  AlertTriangle,
  Heart,
  Share2,
} from 'lucide-react';
import { BloodDonor, BloodRequest, BloodGroup } from '../types';
import { useAuth } from '../context/AuthContext';
import { createBloodRequest, registerBloodDonor } from '../services/firestoreService';
import { ImageUploadInput } from '../components/ImageUploadInput';

interface BloodScreenProps {
  requests: BloodRequest[];
  donors: BloodDonor[];
  onRequireAuth: (hint: string) => void;
}

const BLOOD_GROUPS: BloodGroup[] = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

export const BloodScreen: React.FC<BloodScreenProps> = ({
  requests,
  donors,
  onRequireAuth,
}) => {
  const { currentUser, profile } = useAuth();
  const [activeTab, setActiveTab] = useState<'requests' | 'donors'>('requests');
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [showDonorModal, setShowDonorModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Request form state
  const [patientName, setPatientName] = useState('');
  const [reqBloodGroup, setReqBloodGroup] = useState<BloodGroup>('A+');
  const [hospital, setHospital] = useState('');
  const [location, setLocation] = useState('');
  const [requiredDate, setRequiredDate] = useState('');
  const [units, setUnits] = useState(1);
  const [contact, setContact] = useState('');
  const [urgency, setUrgency] = useState<'normal' | 'emergency' | 'critical'>('emergency');
  const [notes, setNotes] = useState('');

  // Donor form state
  const [donorName, setDonorName] = useState(profile?.name || '');
  const [donorGroup, setDonorGroup] = useState<BloodGroup>('O+');
  const [donorPhone, setDonorPhone] = useState(profile?.phone || '');
  const [donorAddress, setDonorAddress] = useState('');
  const [lastDonation, setLastDonation] = useState('');
  const [donorPhoto, setDonorPhoto] = useState('');

  // Filtered lists
  const filteredRequests = requests.filter((r) =>
    selectedGroup === 'all' ? true : r.bloodGroup === selectedGroup
  );

  const filteredDonors = donors.filter((d) =>
    selectedGroup === 'all' ? true : d.bloodGroup === selectedGroup
  );

  const handleOpenRequestModal = () => {
    if (!currentUser) {
      onRequireAuth('রক্তের আবেদন করতে লগইন করা প্রয়োজন');
      return;
    }
    setShowRequestModal(true);
  };

  const handleOpenDonorModal = () => {
    if (!currentUser) {
      onRequireAuth('রক্তদাতা হিসেবে নিবন্ধন করতে লগইন প্রয়োজন');
      return;
    }
    setShowDonorModal(true);
  };

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setSubmitting(true);
    try {
      await createBloodRequest({
        patientName,
        bloodGroup: reqBloodGroup,
        hospital,
        location,
        requiredDate: requiredDate || new Date().toISOString().split('T')[0],
        units: Number(units) || 1,
        contact,
        urgency,
        status: 'pending',
        notes,
        requesterUid: currentUser.uid,
        requesterName: profile?.name || currentUser.displayName || 'আবেদনকারী',
      });
      setShowRequestModal(false);
      // Reset form
      setPatientName('');
      setHospital('');
      setLocation('');
      setContact('');
      setNotes('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegisterDonor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    setSubmitting(true);
    try {
      await registerBloodDonor({
        userId: currentUser.uid,
        name: donorName,
        phone: donorPhone,
        bloodGroup: donorGroup,
        photoURL: donorPhoto,
        address: donorAddress,
        donationCount: 1,
        lastDonationDate: lastDonation,
        isAvailable: true,
      });
      setShowDonorModal(false);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-red-900 via-red-800 to-red-950 text-white rounded-3xl p-5 shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-red-700/80 text-white">
              <Droplet size={18} />
            </span>
            <h2 className="text-lg font-bold">আদবাড়িয়া জরুরি রক্তদান সেবা</h2>
          </div>
          <p className="text-xs text-red-100 max-w-md leading-relaxed">
            রক্ত দিন, জীবন বাঁচান। জরুরি প্রয়োজনে সরাসরি রক্তদাতার সাথে যোগাযোগ করুন অথবা একটি আবেদন করুন।
          </p>

          <div className="flex items-center gap-2 mt-4">
            <button
              onClick={handleOpenRequestModal}
              className="px-3.5 py-2 bg-white text-red-900 hover:bg-red-50 text-xs font-bold rounded-xl transition shadow flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={15} /> রক্তের আবেদন করুন
            </button>
            <button
              onClick={handleOpenDonorModal}
              className="px-3.5 py-2 bg-red-700 hover:bg-red-600 text-white text-xs font-bold rounded-xl transition shadow border border-red-500/60 flex items-center gap-1.5 cursor-pointer"
            >
              <Heart size={15} /> রক্তদাতা হোন
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex rounded-2xl bg-slate-200/80 p-1">
        <button
          onClick={() => setActiveTab('requests')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeTab === 'requests'
              ? 'bg-white text-red-800 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Droplet size={14} /> রক্তের আবেদনসমূহ ({requests.length})
        </button>
        <button
          onClick={() => setActiveTab('donors')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
            activeTab === 'donors'
              ? 'bg-white text-red-800 shadow-sm'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <UserCheck size={14} /> রক্তদাতাদের তালিকা ({donors.length})
        </button>
      </div>

      {/* Blood Group Filter Pill Bar */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
        <button
          onClick={() => setSelectedGroup('all')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl shrink-0 transition ${
            selectedGroup === 'all'
              ? 'bg-red-700 text-white shadow-xs'
              : 'bg-white text-slate-700 border border-slate-200'
          }`}
        >
          সকল গ্রুপ
        </button>
        {BLOOD_GROUPS.map((bg) => (
          <button
            key={bg}
            onClick={() => setSelectedGroup(bg)}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl shrink-0 transition ${
              selectedGroup === bg
                ? 'bg-red-700 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:border-red-300'
            }`}
          >
            {bg}
          </button>
        ))}
      </div>

      {/* Requests Tab Content */}
      {activeTab === 'requests' && (
        <div className="space-y-3">
          {filteredRequests.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <Droplet size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">বর্তমানে কোনো রক্তের আবেদন নেই</h4>
              <p className="text-xs text-slate-400 mt-1">
                কারো রক্তের প্রয়োজন হলে উপরে &quot;রক্তের আবেদন করুন&quot; বাটনে চাপ দিয়ে তথ্য যুক্ত করুন।
              </p>
            </div>
          ) : (
            filteredRequests.map((req) => (
              <div
                key={req.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs hover:border-red-200 transition"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-red-600 text-white flex flex-col items-center justify-center font-black shadow-xs shrink-0">
                      <span className="text-sm leading-none">{req.bloodGroup}</span>
                      <span className="text-[9px] font-medium opacity-90">{req.units} ব্যাগ</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-sm text-slate-900">{req.patientName}</h3>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                            req.urgency === 'critical'
                              ? 'bg-red-100 text-red-800'
                              : req.urgency === 'emergency'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-blue-100 text-blue-800'
                          }`}
                        >
                          {req.urgency === 'critical'
                            ? 'খুবই জরুরি'
                            : req.urgency === 'emergency'
                            ? 'জরুরি'
                            : 'সাধারণ'}
                        </span>
                        {req.status === 'fulfilled' && (
                          <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-2 py-0.2 rounded-full">
                            রক্ত পাওয়া গেছে
                          </span>
                        )}
                      </div>

                      <div className="text-xs text-slate-600 mt-1 space-y-0.5">
                        <div className="flex items-center gap-1.5 text-slate-700">
                          <MapPin size={13} className="text-red-500 shrink-0" />
                          <span>{req.hospital}, {req.location}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                          <Calendar size={13} className="shrink-0" />
                          <span>প্রয়োজনের তারিখ: {req.requiredDate}</span>
                        </div>
                        {req.notes && (
                          <p className="text-[11px] text-slate-500 italic mt-1">
                            &ldquo;{req.notes}&rdquo;
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <a
                    href={`tel:${req.contact}`}
                    className="px-3.5 py-2 bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm shrink-0"
                  >
                    <Phone size={14} /> কল
                  </a>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Donors Tab Content */}
      {activeTab === 'donors' && (
        <div className="space-y-3">
          {filteredDonors.length === 0 ? (
            <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
              <UserCheck size={38} className="mx-auto text-slate-300 mb-2" />
              <h4 className="font-bold text-sm text-slate-700">এই গ্রুপের কোনো রক্তদাতা পাওয়া যায়নি</h4>
              <p className="text-xs text-slate-400 mt-1">
                আপনি রক্তদান করতে ইচ্ছুক হলে &quot;রক্তদাতা হোন&quot; বাটনে চাপ দিয়ে নিবন্ধন করুন।
              </p>
            </div>
          ) : (
            filteredDonors.map((donor) => (
              <div
                key={donor.id}
                className="bg-white rounded-2xl p-4 border border-slate-200/80 shadow-xs flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3">
                  {donor.photoURL ? (
                    <img
                      src={donor.photoURL}
                      alt={donor.name}
                      className="w-12 h-12 rounded-2xl object-cover border border-slate-200 shrink-0"
                    />
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm shrink-0">
                      {donor.name.charAt(0)}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-slate-900">{donor.name}</h4>
                      <span className="px-2 py-0.5 rounded-md bg-red-600 text-white font-extrabold text-xs">
                        {donor.bloodGroup}
                      </span>
                    </div>

                    <div className="text-xs text-slate-500 mt-0.5">
                      <span>{donor.address || 'আদবাড়িয়া'}</span>
                      {donor.lastDonationDate && (
                        <span className="ml-2 text-[11px] text-slate-400">
                          (শেষ রক্তদান: {donor.lastDonationDate})
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-1.5 mt-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <span className="text-[10px] text-emerald-700 font-semibold">
                        {donor.isAvailable ? 'রক্তদানে প্রস্তুত' : 'অনুপলব্ধ'}
                      </span>
                    </div>
                  </div>
                </div>

                <a
                  href={`tel:${donor.phone}`}
                  className="px-3.5 py-2 bg-emerald-800 hover:bg-emerald-900 active:scale-95 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 shadow-sm shrink-0"
                >
                  <Phone size={13} /> কল দিন
                </a>
              </div>
            ))
          )}
        </div>
      )}

      {/* Blood Request Modal */}
      {showRequestModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-red-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Droplet className="text-red-600" size={18} />
                জরুরি রক্তের আবেদন
              </h3>
              <button
                onClick={() => setShowRequestModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateRequest} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  রোগীর নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={patientName}
                  onChange={(e) => setPatientName(e.target.value)}
                  placeholder="রোগীর নাম"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    রক্তের গ্রুপ <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={reqBloodGroup}
                    onChange={(e) => setReqBloodGroup(e.target.value as BloodGroup)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600 bg-white"
                  >
                    {BLOOD_GROUPS.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    রক্তের পরিমাণ (ব্যাগ)
                  </label>
                  <input
                    type="number"
                    min={1}
                    max={10}
                    value={units}
                    onChange={(e) => setUnits(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  হাসপাতাল / ক্লিনিকের নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={hospital}
                  onChange={(e) => setHospital(e.target.value)}
                  placeholder="যেমন: কুষ্টিয়া জেনারেল হাসপাতাল"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ঠিকানা / এলাকা <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="আদবাড়িয়া / কুষ্টিয়া"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    রক্তদানের তারিখ <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={requiredDate}
                    onChange={(e) => setRequiredDate(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  যোগাযোগের মোবাইল নম্বর <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  required
                  value={contact}
                  onChange={(e) => setContact(e.target.value)}
                  placeholder="০১৭১২-XXXXXX"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  জরুরিতা (Urgency)
                </label>
                <select
                  value={urgency}
                  onChange={(e) => setUrgency(e.target.value as any)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600 bg-white"
                >
                  <option value="critical">খুবই জরুরি (এখনই প্রয়োজন)</option>
                  <option value="emergency">জরুরি (আজকের মধ্যে)</option>
                  <option value="normal">সাধারণ (নির্দিষ্ট তারিখে)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  বিশেষ তথ্য (যদি থাকে)
                </label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="যেমন: রোগীর থ্যালাসেমিয়া বা অপারেশন"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-600"
                />
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                {submitting ? 'জমা হচ্ছে...' : 'আবেদন পোস্ট করুন'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Donor Registration Modal */}
      {showDonorModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Heart className="text-red-600" size={18} />
                রক্তদাতা নিবন্ধন ফরম
              </h3>
              <button
                onClick={() => setShowDonorModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleRegisterDonor} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  রক্তদাতার নাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="আপনার পূর্ণ নাম"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    রক্তের গ্রুপ <span className="text-red-500">*</span>
                  </label>
                  <select
                    value={donorGroup}
                    onChange={(e) => setDonorGroup(e.target.value as BloodGroup)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-white"
                  >
                    {BLOOD_GROUPS.map((g) => (
                      <option key={g} value={g}>
                        {g}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    মোবাইল নম্বর <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={donorPhone}
                    onChange={(e) => setDonorPhone(e.target.value)}
                    placeholder="০১৭১২-XXXXXX"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  স্থায়ী ঠিকানা / এলাকা <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={donorAddress}
                  onChange={(e) => setDonorAddress(e.target.value)}
                  placeholder="গ্রাম: আদবাড়িয়া, ডাকঘর: ..."
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  সর্বশেষ রক্তদানের তারিখ (যদি পূর্বে দিয়ে থাকেন)
                </label>
                <input
                  type="date"
                  value={lastDonation}
                  onChange={(e) => setLastDonation(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <ImageUploadInput
                label="রক্তদাতার ছবি (ঐচ্ছিক)"
                value={donorPhoto}
                onChange={setDonorPhoto}
              />

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                {submitting ? 'নিবন্ধন হচ্ছে...' : 'রক্তদাতা হিসেবে যুক্ত হোন'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
