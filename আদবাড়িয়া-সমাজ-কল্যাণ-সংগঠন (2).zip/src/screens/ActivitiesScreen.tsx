import React, { useState } from 'react';
import {
  Flame,
  Calendar,
  MapPin,
  Users,
  Heart,
  Plus,
  Trash2,
  Edit3,
  CheckCircle2,
  Clock,
  Sparkles,
} from 'lucide-react';
import { HumanitarianActivity } from '../types';
import { useAuth } from '../context/AuthContext';
import { addActivity, deleteActivity } from '../services/firestoreService';
import { ImageUploadInput } from '../components/ImageUploadInput';

interface ActivitiesScreenProps {
  activities: HumanitarianActivity[];
  onRequireAuth: (hint: string) => void;
}

export const ActivitiesScreen: React.FC<ActivitiesScreenProps> = ({
  activities,
  onRequireAuth,
}) => {
  const { isAdmin, isSuperAdmin, currentUser } = useAuth();
  const [filter, setFilter] = useState<'all' | 'ongoing' | 'completed'>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('খাদ্য বিতরণ');
  const [imageUrl, setImageUrl] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [location, setLocation] = useState('আদবাড়িয়া');
  const [participants, setParticipants] = useState(15);
  const [beneficiaries, setBeneficiaries] = useState(50);
  const [budget, setBudget] = useState(10000);
  const [status, setStatus] = useState<'ongoing' | 'completed'>('completed');

  const filtered = activities.filter((act) => {
    if (filter === 'all') return true;
    return act.status === filter;
  });

  const handleCreateActivity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin && !isSuperAdmin) return;
    setSubmitting(true);
    try {
      await addActivity({
        title,
        description,
        category,
        imageUrl,
        date,
        location,
        participants: Number(participants) || 0,
        beneficiaries: Number(beneficiaries) || 0,
        budget: Number(budget) || 0,
        status,
        createdBy: currentUser?.uid,
      });
      setShowAddModal(false);
      setTitle('');
      setDescription('');
      setImageUrl('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('আপনি কি নিশ্চিত যে এই কার্যক্রমটি মুছে ফেলতে চান?')) {
      await deleteActivity(id);
    }
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Banner */}
      <div className="bg-gradient-to-r from-emerald-900 via-emerald-800 to-emerald-950 text-white rounded-3xl p-5 shadow-lg flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-amber-400 text-slate-950">
              <Flame size={18} />
            </span>
            <h2 className="text-lg font-bold">মানবিক ও সামাজিক কার্যক্রম</h2>
          </div>
          <p className="text-xs text-emerald-200">
            আদবাড়িয়া সমাজ কল্যাণ সংগঠনের মাঠপর্যায়ে বাস্তবায়িত ও চলমান উন্নয়ন প্রকল্পসমূহ।
          </p>
        </div>

        {(isAdmin || isSuperAdmin) && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-xl transition shadow flex items-center gap-1 shrink-0 cursor-pointer"
          >
            <Plus size={15} /> কার্যক্রম যোগ করুন
          </button>
        )}
      </div>

      {/* Filter Chips */}
      <div className="flex gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl transition ${
            filter === 'all'
              ? 'bg-emerald-900 text-white'
              : 'bg-white text-slate-700 border border-slate-200'
          }`}
        >
          সকল কার্যক্রম ({activities.length})
        </button>
        <button
          onClick={() => setFilter('ongoing')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl transition ${
            filter === 'ongoing'
              ? 'bg-amber-500 text-slate-950'
              : 'bg-white text-slate-700 border border-slate-200'
          }`}
        >
          চলমান প্রকল্প
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl transition ${
            filter === 'completed'
              ? 'bg-emerald-700 text-white'
              : 'bg-white text-slate-700 border border-slate-200'
          }`}
        >
          সম্পন্ন কার্যক্রম
        </button>
      </div>

      {/* Activities Grid */}
      {filtered.length === 0 ? (
        <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
          <Flame size={38} className="mx-auto text-slate-300 mb-2" />
          <h4 className="font-bold text-sm text-slate-700">বর্তমানে কোনো কার্যক্রম নেই</h4>
          <p className="text-xs text-slate-400 mt-1">
            অ্যাডমিন প্যানেল থেকে বাস্তবায়িত কার্যক্রম পোস্ট করলে তা সাথে সাথে এখানে দেখা যাবে।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filtered.map((act) => (
            <div
              key={act.id}
              className="bg-white rounded-3xl border border-slate-200/90 overflow-hidden shadow-xs hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                {act.imageUrl ? (
                  <div className="h-44 w-full overflow-hidden relative">
                    <img
                      src={act.imageUrl}
                      alt={act.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-3 left-3">
                      <span
                        className={`text-[10px] font-bold px-2.5 py-1 rounded-full shadow ${
                          act.status === 'completed'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-amber-500 text-slate-950'
                        }`}
                      >
                        {act.status === 'completed' ? 'সম্পন্ন' : 'চলমান প্রকল্প'}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="h-28 bg-gradient-to-r from-emerald-800 to-emerald-950 p-4 text-white flex items-end">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        act.status === 'completed'
                          ? 'bg-emerald-600 text-white'
                          : 'bg-amber-500 text-slate-950'
                      }`}
                    >
                      {act.status === 'completed' ? 'সম্পন্ন' : 'চলমান প্রকল্প'}
                    </span>
                  </div>
                )}

                <div className="p-4">
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1.5">
                    <span className="flex items-center gap-1"><Calendar size={12} /> {act.date}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1"><MapPin size={12} /> {act.location}</span>
                  </div>

                  <h3 className="font-bold text-sm text-slate-900 mb-1.5 leading-snug">{act.title}</h3>
                  <p className="text-xs text-slate-600 leading-relaxed line-clamp-3">{act.description}</p>
                </div>
              </div>

              <div className="px-4 pb-4 pt-2 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3 text-[11px] text-slate-600 font-medium">
                  <div>
                    উপকারভোগী: <strong className="text-emerald-800">{act.beneficiaries} জন</strong>
                  </div>
                  {act.budget > 0 && (
                    <div>
                      বাজেট: <strong className="text-slate-900">৳ {act.budget.toLocaleString()}</strong>
                    </div>
                  )}
                </div>

                {(isAdmin || isSuperAdmin) && (
                  <button
                    onClick={() => handleDelete(act.id)}
                    className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg transition"
                    title="মুছে ফেলুন"
                  >
                    <Trash2 size={15} />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Add Activity Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-emerald-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Flame className="text-amber-500" size={18} />
                নতুন মানবিক কার্যক্রম যুক্ত করুন
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateActivity} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  কার্যক্রমের শিরোনাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="যেমন: পবিত্র রমজানে দরিদ্রদের মাঝে ইফতার সামগ্রী বিতরণ"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  বিবরণ <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="কার্যক্রমের বিস্তারিত উদ্দেশ্য ও অগ্রগতি..."
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ক্যাটাগরি
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="খাদ্য / রক্তদান / শিক্ষা"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    তারিখ
                  </label>
                  <input
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    স্থান / এলাকা
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="আদবাড়িয়া বাজার"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    প্রকল্পের অবস্থা
                  </label>
                  <select
                    value={status}
                    onChange={(e) => setStatus(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-white"
                  >
                    <option value="completed">সম্পন্ন (Completed)</option>
                    <option value="ongoing">চলমান (Ongoing)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    উপকারভোগী (জন)
                  </label>
                  <input
                    type="number"
                    value={beneficiaries}
                    onChange={(e) => setBeneficiaries(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    অংশগ্রহণকারী
                  </label>
                  <input
                    type="number"
                    value={participants}
                    onChange={(e) => setParticipants(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                    মোট খরচ (টাকা)
                  </label>
                  <input
                    type="number"
                    value={budget}
                    onChange={(e) => setBudget(Number(e.target.value))}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <ImageUploadInput
                label="কার্যক্রমের ছবি (অপ্টিমাইজড)"
                value={imageUrl}
                onChange={setImageUrl}
              />

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-emerald-800 hover:bg-emerald-900 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                {submitting ? 'সংরক্ষণ হচ্ছে...' : 'কার্যক্রম প্রকাশ করুন'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
