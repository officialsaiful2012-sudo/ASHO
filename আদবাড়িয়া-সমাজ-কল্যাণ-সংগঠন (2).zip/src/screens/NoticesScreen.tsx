import React, { useState } from 'react';
import {
  BellRing,
  Calendar,
  AlertCircle,
  Plus,
  Trash2,
  Clock,
  Sparkles,
  Megaphone,
} from 'lucide-react';
import { Notice } from '../types';
import { useAuth } from '../context/AuthContext';
import { addNotice, deleteNotice } from '../services/firestoreService';

interface NoticesScreenProps {
  notices: Notice[];
  onRequireAuth: (hint: string) => void;
}

export const NoticesScreen: React.FC<NoticesScreenProps> = ({ notices, onRequireAuth }) => {
  const { isAdmin, isSuperAdmin, currentUser, profile } = useAuth();
  const [filter, setFilter] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Form states
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<Notice['category']>('notice');
  const [priority, setPriority] = useState<'normal' | 'urgent'>('normal');
  const [eventDate, setEventDate] = useState('');
  const [location, setLocation] = useState('');

  const filtered = notices.filter((n) => {
    if (filter === 'all') return true;
    return n.category === filter;
  });

  const handleCreateNotice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin && !isSuperAdmin) return;
    setSubmitting(true);
    try {
      await addNotice({
        title,
        content,
        category,
        date: new Date().toISOString().split('T')[0],
        eventDate: eventDate || undefined,
        location: location || undefined,
        priority,
        authorName: profile?.name || 'অফিসিয়াল প্রশাসন',
      });
      setShowAddModal(false);
      setTitle('');
      setContent('');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('আপনি কি এই নোটিশটি মুছে ফেলতে চান?')) {
      await deleteNotice(id);
    }
  };

  return (
    <div className="space-y-4 pb-20 text-left font-['Hind_Siliguri']">
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-700 via-amber-800 to-amber-900 text-white rounded-3xl p-5 shadow-lg flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-xl bg-white/20 text-white">
              <BellRing size={18} />
            </span>
            <h2 className="text-lg font-bold">অফিসিয়াল নোটিশ ও ইভেন্ট</h2>
          </div>
          <p className="text-xs text-amber-100">
            সংগঠনের সকল সাধারণ সভা, জরুরি বিজ্ঞপ্তি ও মানবিক কর্মসূচির সর্বশেষ নোটিশ।
          </p>
        </div>

        {(isAdmin || isSuperAdmin) && (
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3.5 py-2 bg-white text-amber-900 hover:bg-amber-50 text-xs font-bold rounded-xl transition shadow flex items-center gap-1 shrink-0 cursor-pointer"
          >
            <Plus size={15} /> নোটিশ প্রকাশ
          </button>
        )}
      </div>

      {/* Filter Chips */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'all', label: 'সকল নোটিশ' },
          { id: 'notice', label: 'সাধারণ নোটিশ' },
          { id: 'announcement', label: 'জরুরি ঘোষণা' },
          { id: 'meeting', label: 'মিটিং / সভা' },
          { id: 'event', label: 'ইভেন্ট / কর্মসূচি' },
        ].map((item) => (
          <button
            key={item.id}
            onClick={() => setFilter(item.id)}
            className={`px-3 py-1.5 text-xs font-bold rounded-xl shrink-0 transition ${
              filter === item.id
                ? 'bg-amber-800 text-white'
                : 'bg-white text-slate-700 border border-slate-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Notices List */}
      {filtered.length === 0 ? (
        <div className="py-14 text-center bg-white rounded-3xl border border-slate-200 p-6">
          <BellRing size={38} className="mx-auto text-slate-300 mb-2" />
          <h4 className="font-bold text-sm text-slate-700">বর্তমানে কোনো নোটিশ নেই</h4>
          <p className="text-xs text-slate-400 mt-1">
            নতুন কোনো নোটিশ বা মিটিং থাকলে এখানে সাথে সাথে দেখতে পাবেন।
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((notice) => (
            <div
              key={notice.id}
              className={`bg-white rounded-3xl p-4 border transition ${
                notice.priority === 'urgent'
                  ? 'border-red-300 shadow-sm bg-red-50/20'
                  : 'border-slate-200/90 shadow-xs'
              }`}
            >
              <div className="flex items-start justify-between gap-3 mb-2">
                <div className="flex items-center gap-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      notice.priority === 'urgent'
                        ? 'bg-red-600 text-white animate-pulse'
                        : 'bg-amber-100 text-amber-900'
                    }`}
                  >
                    {notice.priority === 'urgent' ? 'জরুরি নোটিশ' : 'নোটিশ'}
                  </span>
                  <span className="text-[11px] text-slate-400">{notice.date}</span>
                </div>

                {(isAdmin || isSuperAdmin) && (
                  <button
                    onClick={() => handleDelete(notice.id)}
                    className="text-slate-400 hover:text-red-600 p-1 rounded transition"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>

              <h3 className="font-bold text-sm text-slate-900 mb-1.5">{notice.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">
                {notice.content}
              </p>

              {(notice.eventDate || notice.location) && (
                <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center gap-4 text-[11px] text-slate-500">
                  {notice.eventDate && (
                    <div className="flex items-center gap-1 text-emerald-800 font-medium">
                      <Calendar size={12} /> সভার তারিখ: {notice.eventDate}
                    </div>
                  )}
                  {notice.location && (
                    <div className="flex items-center gap-1">
                      স্থান: {notice.location}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Add Notice Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-amber-100 max-h-[90vh] overflow-y-auto">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
                <Megaphone className="text-amber-600" size={18} />
                নতুন নোটিশ প্রকাশ করুন
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateNotice} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  নোটিশের শিরোনাম <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="যেমন: আগামী শুক্রবার জরুরি মাসিক সাধারণ সভা"
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ক্যাটাগরি
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                  >
                    <option value="notice">সাধারণ নোটিশ</option>
                    <option value="announcement">জরুরি ঘোষণা</option>
                    <option value="meeting">মাসিক / জরুরি সভা</option>
                    <option value="event">ইভেন্ট কর্মসূচি</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    গুরুত্ব (Priority)
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value as any)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600 bg-white"
                  >
                    <option value="normal">সাধারণ</option>
                    <option value="urgent">জরুরি (Urgent)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  নোটিশের বিস্তারিত বক্তব্য <span className="text-red-500">*</span>
                </label>
                <textarea
                  rows={4}
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="নোটিশের বিস্তারিত তথ্য লিখুন..."
                  className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    সভার তারিখ (যদি থাকে)
                  </label>
                  <input
                    type="date"
                    value={eventDate}
                    onChange={(e) => setEventDate(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    স্থান (যদি থাকে)
                  </label>
                  <input
                    type="text"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="আদবাড়িয়া ইউনিয়ন পরিষদ"
                    className="w-full text-xs px-3 py-2 border border-slate-200 rounded-xl"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full py-2.5 bg-amber-800 hover:bg-amber-900 text-white font-bold text-xs rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer mt-2"
              >
                {submitting ? 'প্রকাশ হচ্ছে...' : 'নোটিশ প্রকাশ করুন'}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
