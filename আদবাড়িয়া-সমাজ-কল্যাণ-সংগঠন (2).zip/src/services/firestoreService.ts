import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  orderBy,
  serverTimestamp,
  Unsubscribe,
} from 'firebase/firestore';
import { db, SUPER_ADMIN_UID, DEFAULT_ORG_ID } from '../config/firebase';
import {
  UserProfile,
  ServiceCategory,
  BloodDonor,
  BloodRequest,
  HumanitarianActivity,
  OrgMember,
  OrgVolunteer,
  Contribution,
  Donation,
  Expense,
  Notice,
  ChatMessage,
  AppNotification,
} from '../types';
import { DEFAULT_SERVICE_CATEGORIES } from '../config/defaultServices';

// ========================
// USERS & ROLES
// ========================

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const docRef = doc(db, 'users', uid);
  const snap = await getDoc(docRef);
  if (snap.exists()) {
    return snap.data() as UserProfile;
  }
  return null;
}

export async function syncUserProfile(user: {
  uid: string;
  email: string | null;
  displayName: string | null;
  phoneNumber?: string | null;
  photoURL?: string | null;
}): Promise<UserProfile> {
  const docRef = doc(db, 'users', user.uid);
  const snap = await getDoc(docRef);

  const isSuper = user.uid === SUPER_ADMIN_UID;

  if (!snap.exists()) {
    const newProfile: UserProfile = {
      uid: user.uid,
      name: user.displayName || user.email?.split('@')[0] || 'সম্মানিত সদস্য',
      email: user.email || '',
      phone: user.phoneNumber || '',
      photoURL: user.photoURL || '',
      organizationId: DEFAULT_ORG_ID,
      role: isSuper ? 'super_admin' : 'member',
      permissions: isSuper ? ['all'] : [],
      status: 'active',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    };
    await setDoc(docRef, newProfile);
    return newProfile;
  } else {
    const existing = snap.data() as UserProfile;
    // Always guarantee Super Admin UID has super_admin role
    if (isSuper && existing.role !== 'super_admin') {
      await updateDoc(docRef, { role: 'super_admin', permissions: ['all'], updatedAt: serverTimestamp() });
      existing.role = 'super_admin';
    }
    return existing;
  }
}

export async function updateUserRole(uid: string, role: 'member' | 'admin' | 'super_admin', permissions: string[] = []) {
  const docRef = doc(db, 'users', uid);
  await updateDoc(docRef, { role, permissions, updatedAt: serverTimestamp() });
}

export function subscribeUsers(callback: (users: UserProfile[]) => void): Unsubscribe {
  const q = collection(db, 'users');
  return onSnapshot(q, (snapshot) => {
    const users = snapshot.docs.map((d) => d.data() as UserProfile);
    callback(users);
  }, (err) => {
    console.error('Error fetching users:', err);
    callback([]);
  });
}

// ========================
// SERVICES
// ========================

export function subscribeServices(callback: (services: ServiceCategory[]) => void): Unsubscribe {
  const q = collection(db, 'services');
  return onSnapshot(q, (snapshot) => {
    const services = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as ServiceCategory));
    services.sort((a, b) => (a.order || 0) - (b.order || 0));
    callback(services);
  }, (err) => {
    console.error('Error fetching services:', err);
    callback([]);
  });
}

export async function addService(service: Omit<ServiceCategory, 'id'>) {
  return await addDoc(collection(db, 'services'), {
    ...service,
    createdAt: serverTimestamp(),
  });
}

export async function updateService(id: string, updates: Partial<ServiceCategory>) {
  return await updateDoc(doc(db, 'services', id), updates);
}

export async function deleteService(id: string) {
  return await deleteDoc(doc(db, 'services', id));
}

export async function importDefaultServices() {
  const currentSnap = await getDocs(collection(db, 'services'));
  if (currentSnap.empty) {
    for (const service of DEFAULT_SERVICE_CATEGORIES) {
      await addDoc(collection(db, 'services'), {
        ...service,
        createdAt: serverTimestamp(),
      });
    }
    return true;
  }
  return false;
}

// ========================
// BLOOD DONATION
// ========================

export function subscribeBloodDonors(callback: (donors: BloodDonor[]) => void): Unsubscribe {
  const q = collection(db, 'donors');
  return onSnapshot(q, (snapshot) => {
    const donors = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as BloodDonor));
    callback(donors);
  }, (err) => {
    console.error('Error fetching blood donors:', err);
    callback([]);
  });
}

export async function registerBloodDonor(donor: Omit<BloodDonor, 'id' | 'createdAt'>) {
  return await addDoc(collection(db, 'donors'), {
    ...donor,
    createdAt: serverTimestamp(),
  });
}

export function subscribeBloodRequests(callback: (requests: BloodRequest[]) => void): Unsubscribe {
  const q = collection(db, 'bloodRequests');
  return onSnapshot(q, (snapshot) => {
    const requests = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as BloodRequest));
    // Sort descending by created date
    requests.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    callback(requests);
  }, (err) => {
    console.error('Error fetching blood requests:', err);
    callback([]);
  });
}

export async function createBloodRequest(request: Omit<BloodRequest, 'id' | 'createdAt'>) {
  const ref = await addDoc(collection(db, 'bloodRequests'), {
    ...request,
    createdAt: serverTimestamp(),
  });

  // Broadcast notification for emergency blood
  await addDoc(collection(db, 'notifications'), {
    title: `জরুরি রক্তের আবেদন: ${request.bloodGroup}`,
    message: `${request.hospital}, ${request.location}-এ ${request.patientName}-এর জন্য ${request.units} ব্যাগ রক্ত প্রয়োজন।`,
    type: 'blood',
    read: false,
    createdAt: serverTimestamp(),
  });

  return ref;
}

export async function updateBloodRequestStatus(id: string, status: BloodRequest['status']) {
  return await updateDoc(doc(db, 'bloodRequests', id), { status });
}

// ========================
// HUMANITARIAN ACTIVITIES
// ========================

export function subscribeActivities(callback: (activities: HumanitarianActivity[]) => void): Unsubscribe {
  const q = collection(db, 'activities');
  return onSnapshot(q, (snapshot) => {
    const activities = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as HumanitarianActivity));
    activities.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    callback(activities);
  }, (err) => {
    console.error('Error fetching activities:', err);
    callback([]);
  });
}

export async function addActivity(activity: Omit<HumanitarianActivity, 'id' | 'createdAt'>) {
  const ref = await addDoc(collection(db, 'activities'), {
    ...activity,
    createdAt: serverTimestamp(),
  });

  await addDoc(collection(db, 'notifications'), {
    title: `নতুন মানবিক কার্যক্রম: ${activity.title}`,
    message: `${activity.location}-এ কার্যক্রম সম্পন্ন/শুরু হয়েছে। উপকারভোগী: ${activity.beneficiaries} জন।`,
    type: 'activity',
    read: false,
    createdAt: serverTimestamp(),
  });

  return ref;
}

export async function updateActivity(id: string, updates: Partial<HumanitarianActivity>) {
  return await updateDoc(doc(db, 'activities', id), updates);
}

export async function deleteActivity(id: string) {
  return await deleteDoc(doc(db, 'activities', id));
}

// ========================
// MEMBERS & VOLUNTEERS
// ========================

export function subscribeMembers(callback: (members: OrgMember[]) => void): Unsubscribe {
  const q = collection(db, 'members');
  return onSnapshot(q, (snapshot) => {
    const members = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as OrgMember));
    members.sort((a, b) => (a.order || 99) - (b.order || 99));
    callback(members);
  }, (err) => {
    console.error('Error fetching members:', err);
    callback([]);
  });
}

export async function addMember(member: Omit<OrgMember, 'id'>) {
  return await addDoc(collection(db, 'members'), {
    ...member,
    createdAt: serverTimestamp(),
  });
}

export async function updateMember(id: string, updates: Partial<OrgMember>) {
  return await updateDoc(doc(db, 'members', id), updates);
}

export async function deleteMember(id: string) {
  return await deleteDoc(doc(db, 'members', id));
}

export function subscribeVolunteers(callback: (volunteers: OrgVolunteer[]) => void): Unsubscribe {
  const q = collection(db, 'volunteers');
  return onSnapshot(q, (snapshot) => {
    const volunteers = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as OrgVolunteer));
    callback(volunteers);
  }, (err) => {
    console.error('Error fetching volunteers:', err);
    callback([]);
  });
}

export async function addVolunteer(volunteer: Omit<OrgVolunteer, 'id'>) {
  return await addDoc(collection(db, 'volunteers'), {
    ...volunteer,
    createdAt: serverTimestamp(),
  });
}

export async function updateVolunteer(id: string, updates: Partial<OrgVolunteer>) {
  return await updateDoc(doc(db, 'volunteers', id), updates);
}

// ========================
// FINANCE / CONTRIBUTIONS
// ========================

export function subscribeFinance(callback: (data: {
  contributions: Contribution[];
  donations: Donation[];
  expenses: Expense[];
  summary: {
    totalContributions: number;
    totalDonations: number;
    totalExpenses: number;
    balance: number;
  };
}) => void): () => void {
  let contributions: Contribution[] = [];
  let donations: Donation[] = [];
  let expenses: Expense[] = [];

  const calculateAndSend = () => {
    const totalContributions = contributions.reduce((sum, c) => sum + (Number(c.paidAmount) || 0), 0);
    const totalDonations = donations
      .filter((d) => d.status === 'approved' || !d.status)
      .reduce((sum, d) => sum + (Number(d.amount) || 0), 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + (Number(e.amount) || 0), 0);
    const balance = totalContributions + totalDonations - totalExpenses;

    callback({
      contributions,
      donations,
      expenses,
      summary: {
        totalContributions,
        totalDonations,
        totalExpenses,
        balance,
      },
    });
  };

  const unsubC = onSnapshot(collection(db, 'contributions'), (snap) => {
    contributions = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Contribution));
    calculateAndSend();
  });

  const unsubD = onSnapshot(collection(db, 'donations'), (snap) => {
    donations = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Donation));
    calculateAndSend();
  });

  const unsubE = onSnapshot(collection(db, 'expenses'), (snap) => {
    expenses = snap.docs.map((d) => ({ id: d.id, ...d.data() } as Expense));
    calculateAndSend();
  });

  return () => {
    unsubC();
    unsubD();
    unsubE();
  };
}

export async function addContribution(contribution: Omit<Contribution, 'id' | 'createdAt'>) {
  return await addDoc(collection(db, 'contributions'), {
    ...contribution,
    createdAt: serverTimestamp(),
  });
}

export async function addDonation(donation: Omit<Donation, 'id' | 'createdAt'>) {
  return await addDoc(collection(db, 'donations'), {
    ...donation,
    createdAt: serverTimestamp(),
  });
}

export async function addExpense(expense: Omit<Expense, 'id' | 'createdAt'>) {
  return await addDoc(collection(db, 'expenses'), {
    ...expense,
    createdAt: serverTimestamp(),
  });
}

// ========================
// NOTICES & ANNOUNCEMENTS
// ========================

export function subscribeNotices(callback: (notices: Notice[]) => void): Unsubscribe {
  const q = collection(db, 'notices');
  return onSnapshot(q, (snapshot) => {
    const notices = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as Notice));
    notices.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    callback(notices);
  }, (err) => {
    console.error('Error fetching notices:', err);
    callback([]);
  });
}

export async function addNotice(notice: Omit<Notice, 'id' | 'createdAt'>) {
  const ref = await addDoc(collection(db, 'notices'), {
    ...notice,
    createdAt: serverTimestamp(),
  });

  await addDoc(collection(db, 'notifications'), {
    title: `জরুরি নোটিশ: ${notice.title}`,
    message: notice.content.slice(0, 100),
    type: 'notice',
    read: false,
    createdAt: serverTimestamp(),
  });

  return ref;
}

export async function deleteNotice(id: string) {
  return await deleteDoc(doc(db, 'notices', id));
}

// ========================
// MESSAGES (LIVE INTERNET CHAT)
// ========================

export function subscribeMessages(callback: (messages: ChatMessage[]) => void): Unsubscribe {
  const q = collection(db, 'messages');
  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as ChatMessage));
    messages.sort((a, b) => (a.createdAt?.seconds || 0) - (b.createdAt?.seconds || 0));
    callback(messages);
  }, (err) => {
    console.error('Error fetching messages:', err);
    callback([]);
  });
}

export async function sendMessage(msg: Omit<ChatMessage, 'id' | 'createdAt' | 'isSeen'>) {
  return await addDoc(collection(db, 'messages'), {
    ...msg,
    isSeen: false,
    createdAt: serverTimestamp(),
  });
}

// ========================
// NOTIFICATIONS
// ========================

export function subscribeNotifications(callback: (notifications: AppNotification[]) => void): Unsubscribe {
  const q = collection(db, 'notifications');
  return onSnapshot(q, (snapshot) => {
    const list = snapshot.docs.map((d) => ({ id: d.id, ...d.data() } as AppNotification));
    list.sort((a, b) => (b.createdAt?.seconds || 0) - (a.createdAt?.seconds || 0));
    callback(list);
  }, (err) => {
    console.error('Error fetching notifications:', err);
    callback([]);
  });
}

export async function markNotificationAsRead(id: string) {
  return await updateDoc(doc(db, 'notifications', id), { read: true });
}
