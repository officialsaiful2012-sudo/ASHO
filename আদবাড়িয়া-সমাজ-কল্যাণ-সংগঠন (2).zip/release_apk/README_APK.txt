=====================================================
Our Goal — Release APK Directory
আদবাড়িয়া সমাজ কল্যাণ সংগঠন
=====================================================

এই ফোল্ডারে release.apk তৈরি ও সংরক্ষণের জন্য সেটআপ করা হয়েছে।

ফাইলগুলোর লোকেশন:
1. অ্যান্ড্রয়েড স্টুডিও প্রজেক্ট:
   /Our_Goal_Android_App/

2. জেনারেটেড রিলিজ এপিকে (Release APK):
   /release_apk/release.apk
   (অথবা /android/app/build/outputs/apk/release/app-release.apk)

3. সরাসরি ডাউনলোডযোগ্য জিপ:
   /Our_Goal_Android_Project.zip
