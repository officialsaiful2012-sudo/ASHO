package com.asho.asho.repository

import com.asho.asho.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    val superAdminUid = "SI5nqpVS0oYKv9ZFDWV6zNVnK5v1"

    val currentUserId: String? get() = auth.currentUser?.uid
    val isSuperAdmin: Boolean get() = currentUserId == superAdminUid

    // User Profile
    suspend fun getUserProfile(uid: String): UserProfile? {
        val snapshot = firestore.collection("users").document(uid).get().await()
        return snapshot.toObject(UserProfile::class.java)
    }

    // Services
    fun getServicesFlow(): Flow<List<ServiceCategory>> = callbackFlow {
        val listener = firestore.collection("services")
            .orderBy("order", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(ServiceCategory::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // Blood Requests
    fun getBloodRequestsFlow(): Flow<List<BloodRequest>> = callbackFlow {
        val listener = firestore.collection("bloodRequests")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(BloodRequest::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun createBloodRequest(request: BloodRequest) {
        firestore.collection("bloodRequests").add(request).await()
    }

    // Blood Donors
    fun getBloodDonorsFlow(): Flow<List<BloodDonor>> = callbackFlow {
        val listener = firestore.collection("donors")
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(BloodDonor::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // Activities
    fun getActivitiesFlow(): Flow<List<HumanitarianActivity>> = callbackFlow {
        val listener = firestore.collection("activities")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(HumanitarianActivity::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // Notices
    fun getNoticesFlow(): Flow<List<Notice>> = callbackFlow {
        val listener = firestore.collection("notices")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(Notice::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    // Messages (Community Real-Time Chat)
    fun getMessagesFlow(): Flow<List<ChatMessage>> = callbackFlow {
        val listener = firestore.collection("messages")
            .orderBy("createdAt", Query.Direction.ASCENDING)
            .addSnapshotListener { snapshot, _ ->
                val list = snapshot?.documents?.mapNotNull { it.toObject(ChatMessage::class.java)?.copy(id = it.id) } ?: emptyList()
                trySend(list)
            }
        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(message: ChatMessage) {
        firestore.collection("messages").add(message).await()
    }
}
