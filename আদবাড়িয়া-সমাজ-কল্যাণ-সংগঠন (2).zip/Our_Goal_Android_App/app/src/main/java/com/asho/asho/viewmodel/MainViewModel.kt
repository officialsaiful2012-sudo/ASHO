package com.asho.asho.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.asho.asho.model.*
import com.asho.asho.repository.FirebaseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class MainViewModel(
    private val repository: FirebaseRepository = FirebaseRepository()
) : ViewModel() {

    private val _userProfile = MutableStateFlow<UserProfile?>(null)
    val userProfile: StateFlow<UserProfile?> = _userProfile.asStateFlow()

    private val _services = MutableStateFlow<List<ServiceCategory>>(emptyList())
    val services: StateFlow<List<ServiceCategory>> = _services.asStateFlow()

    private val _bloodRequests = MutableStateFlow<List<BloodRequest>>(emptyList())
    val bloodRequests: StateFlow<List<BloodRequest>> = _bloodRequests.asStateFlow()

    private val _bloodDonors = MutableStateFlow<List<BloodDonor>>(emptyList())
    val bloodDonors: StateFlow<List<BloodDonor>> = _bloodDonors.asStateFlow()

    private val _activities = MutableStateFlow<List<HumanitarianActivity>>(emptyList())
    val activities: StateFlow<List<HumanitarianActivity>> = _activities.asStateFlow()

    private val _notices = MutableStateFlow<List<Notice>>(emptyList())
    val notices: StateFlow<List<Notice>> = _notices.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    val isSuperAdmin: Boolean get() = repository.isSuperAdmin

    init {
        loadData()
    }

    private fun loadData() {
        viewModelScope.launch {
            repository.getServicesFlow().collect { _services.value = it }
        }
        viewModelScope.launch {
            repository.getBloodRequestsFlow().collect { _bloodRequests.value = it }
        }
        viewModelScope.launch {
            repository.getBloodDonorsFlow().collect { _bloodDonors.value = it }
        }
        viewModelScope.launch {
            repository.getActivitiesFlow().collect { _activities.value = it }
        }
        viewModelScope.launch {
            repository.getNoticesFlow().collect { _notices.value = it }
        }
        viewModelScope.launch {
            repository.getMessagesFlow().collect { _messages.value = it }
        }
    }

    fun sendChatMessage(text: String, userName: String, userId: String) {
        viewModelScope.launch {
            val msg = ChatMessage(
                senderId = userId,
                senderName = userName,
                text = text
            )
            repository.sendMessage(msg)
        }
    }
}
