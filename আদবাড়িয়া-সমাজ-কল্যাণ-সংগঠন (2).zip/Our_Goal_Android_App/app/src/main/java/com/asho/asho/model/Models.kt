package com.asho.asho.model

import com.google.firebase.Timestamp

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val photoURL: String = "",
    val organizationId: String = "adbariya-samaj-kalyan",
    val role: String = "member", // member, admin, super_admin
    val permissions: List<String> = emptyList(),
    val status: String = "active",
    val bloodGroup: String = "",
    val address: String = ""
)

data class ServiceCategory(
    val id: String = "",
    val title: String = "",
    val titleEn: String = "",
    val description: String = "",
    val icon: String = "",
    val color: String = "#0D522C",
    val active: Boolean = true,
    val order: Int = 0
)

data class BloodDonor(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val phone: String = "",
    val bloodGroup: String = "",
    val photoURL: String = "",
    val address: String = "",
    val donationCount: Int = 0,
    val lastDonationDate: String = "",
    val isAvailable: Boolean = true
)

data class BloodRequest(
    val id: String = "",
    val patientName: String = "",
    val bloodGroup: String = "",
    val hospital: String = "",
    val location: String = "",
    val requiredDate: String = "",
    val units: Int = 1,
    val contact: String = "",
    val urgency: String = "normal", // normal, emergency, critical
    val status: String = "pending", // pending, fulfilled, cancelled
    val notes: String = "",
    val requesterUid: String = "",
    val requesterName: String = "",
    val createdAt: Timestamp? = null
)

data class HumanitarianActivity(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "",
    val imageUrl: String = "",
    val date: String = "",
    val location: String = "",
    val participants: Int = 0,
    val beneficiaries: Int = 0,
    val budget: Double = 0.0,
    val status: String = "ongoing", // ongoing, completed
    val createdAt: Timestamp? = null
)

data class OrgMember(
    val id: String = "",
    val name: String = "",
    val photoURL: String = "",
    val phone: String = "",
    val email: String = "",
    val bloodGroup: String = "",
    val position: String = "",
    val joiningDate: String = "",
    val address: String = "",
    val status: String = "active",
    val order: Int = 99
)

data class OrgVolunteer(
    val id: String = "",
    val name: String = "",
    val photoURL: String = "",
    val phone: String = "",
    val skills: List<String> = emptyList(),
    val availability: String = "anytime",
    val bloodGroup: String = "",
    val joiningDate: String = "",
    val status: String = "active"
)

data class FinancialSummary(
    val totalContributions: Double = 0.0,
    val totalDonations: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val currentBalance: Double = 0.0
)

data class Notice(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val category: String = "notice",
    val date: String = "",
    val priority: String = "normal",
    val createdAt: Timestamp? = null
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderPhoto: String = "",
    val text: String = "",
    val imageUrl: String = "",
    val isSeen: Boolean = false,
    val createdAt: Timestamp? = null
)
