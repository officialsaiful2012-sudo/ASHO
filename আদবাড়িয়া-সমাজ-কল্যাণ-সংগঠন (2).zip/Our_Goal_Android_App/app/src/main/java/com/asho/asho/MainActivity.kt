package com.asho.asho

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import com.asho.asho.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AdbariyaTheme {
                MainApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(mainViewModel: MainViewModel = viewModel()) {
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("আদবাড়িয়া সমাজ কল্যাণ", style = MaterialTheme.typography.titleMedium)
                        Text("মানুষের পাশে, মানবতার জন্য", style = MaterialTheme.typography.bodySmall, color = Color(0xFFD4AF37))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0D522C),
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("হোম") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Handshake, contentDescription = "Services") },
                    label = { Text("সেবা") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Favorite, contentDescription = "Blood") },
                    label = { Text("রক্তদান") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.VolunteerActivism, contentDescription = "Activities") },
                    label = { Text("কার্যক্রম") }
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Forum, contentDescription = "Chat") },
                    label = { Text("মেসেজ") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> HomeScreen(mainViewModel)
                1 -> ServicesScreen(mainViewModel)
                2 -> BloodScreen(mainViewModel)
                3 -> ActivitiesScreen(mainViewModel)
                4 -> ChatScreen(mainViewModel)
            }
        }
    }
}

@Composable
fun HomeScreen(viewModel: MainViewModel) {
    val services by viewModel.services.collectAsState()
    val bloodRequests by viewModel.bloodRequests.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        Card(
            modifier = Modifier.fillMaxWidth().padding(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF0D522C))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "আদবাড়িয়া সমাজ কল্যাণ সংগঠন",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White
                )
                Text(
                    text = "মানুষের পাশে, মানবতার জন্য",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFFF7DF8D)
                )
            }
        }
        Text(
            text = "আমাদের প্রধান সেবাসমূহ",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun ServicesScreen(viewModel: MainViewModel) {
    val services by viewModel.services.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("মানবিক সেবাসমূহ (${services.size})", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun BloodScreen(viewModel: MainViewModel) {
    val requests by viewModel.bloodRequests.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("জরুরি রক্তদান কেন্দ্র", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun ActivitiesScreen(viewModel: MainViewModel) {
    val activities by viewModel.activities.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("মানবিক কার্যক্রমসমূহ", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun ChatScreen(viewModel: MainViewModel) {
    val messages by viewModel.messages.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("সদস্যদের ইন্টারনেট লাইভ চ্যাট", style = MaterialTheme.typography.titleLarge)
    }
}

@Composable
fun AdbariyaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF0D522C),
            secondary = Color(0xFFD4AF37),
            background = Color(0xFFF8FAF9)
        ),
        content = content
    )
}
